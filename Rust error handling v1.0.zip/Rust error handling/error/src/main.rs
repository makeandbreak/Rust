#[allow(unused_imports)]
use std::panic;
use std::error::Error;
use std::fs::File;
use std::io::{self, Read};
use std::fmt;

// Implement Drop in empty Resource
// ---------------------------------

struct Resource;

impl Drop for Resource {
    fn drop(&mut self) {
        println!("Dropping Resource...");
        // Simulate a panic during drop, leading to a double panic
        // panic!("Panic in drop method!");
    }
}

// Function to demonstrate Panic 
// -----------------------------

fn pirate_share(total:u64, crew_size: usize) -> u64 {
    let half = total / 2;
    half / crew_size as u64
}

// A wrapper for .parse to demonstrate Result<> return
// ---------------------------------------------------

fn parse_number(input: &str) -> Result<i32, std::num::ParseIntError> {
    input.parse::<i32>()
}

// Result type aliases
// -------------------

// Define a custom error type

// Implementing Debug allows us to print errors later
#[derive(Debug)]

// Do not warn of dead code (String)
#[allow(dead_code)]
struct MyError(String);

// Create a type alias for a Result type

type MyResult<T> = Result<T, MyError>;

fn parse_number_my_result(input: &str) -> MyResult<i32> {
    input.parse::<i32>()
        .map_err(|_| MyError(format!("Failed to parse '{}' as a number", input)))
}

// .source() example target 
// ------------------------

fn parse_number_source(input: &str) -> Result<i32, Box<dyn Error>> {
    // Attempt to parse the input string as an i32
    // If it fails, we convert the ParseIntError into a Box<dyn Error>
    input.parse::<i32>().map_err(|e| Box::new(e) as Box<dyn Error>)
}

// Propagating errors examples
// ---------------------------

fn _read_file_to_string(filename: &str) -> Result<String, io::Error> {
    let mut file = File::open(filename)?; // Try to open the file, propagate error if it fails.
    let mut contents = String::new();
    file.read_to_string(&mut contents)?; // Read the file contents, propagate error if it fails.
    Ok(contents)
}

fn _parse_number_from_file(filename: &str) -> Result<i32, Box<dyn std::error::Error>> {
    let file_contents = _read_file_to_string(filename)?; // Propagate any errors from _read_file_to_string.
    let number: i32 = file_contents.trim().parse()?; // Try to parse the number, propagate error if it fails.
    Ok(number)
}

// Ignoring errors example
// -----------------------

fn read_file_and_ignore(filename: &str) {
    // Attempt to open the file
    let _file = File::open(filename); // Ignoring any error that occurs while opening the file

    // Attempt to read the file contents
    let mut contents = String::new();
    let _ = _file.map(|mut file| file.read_to_string(&mut contents)); // Ignoring the result of read_to_string
}

// Define a custom error type using an enum
// ----------------------------------------

// Define specific error types

#[derive(Debug)]
struct OutOfRangeError {
    message: String,
}

#[derive(Debug)]
struct InvalidNumberError {
    message: String,
}

// Implement the Display trait for the custom error types

impl fmt::Display for OutOfRangeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Number is out of range: {}", self.message)
    }
}

impl fmt::Display for InvalidNumberError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Number is invalid: {}", self.message)
    }
}

// Implement the Error trait for the custom error types
impl std::error::Error for OutOfRangeError {}
impl std::error::Error for InvalidNumberError {}

#[derive(Debug)]  // Automatically implements the Debug trait for the enum
enum MyAppError {

    // Support three types of errors
    Io(std::io::Error),
    Parse(std::num::ParseIntError),

    // This is specific to Your application
    OutOfRange(OutOfRangeError),
    InvalidNumber(InvalidNumberError),
}

// Implement the Display trait for MyAppError

impl fmt::Display for MyAppError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            MyAppError::Io(err) => write!(f, "I/O error: {}", err),
            MyAppError::Parse(err) => write!(f, "Parse error: {}", err),
            MyAppError::OutOfRange(err) => write!(f, "Number is out of range: {}", err),
            MyAppError::InvalidNumber(err) => write!(f, "Number is invalid: {}", err),
        }
    }
}

// Implement the Error trait for MyAppError

impl std::error::Error for MyAppError {

    // source()  Source of error for referenced instance
    // Return    Some (indicating there is an underlying error)
    //           None (indicating there is no underlying error)
    // dyn       Signifies that type is a dynamically dispatched 
    // + 'static Bound indicates that the type must have a lifetime 
    //           that lasts for the entire duration of the program  
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            MyAppError::Io(err) => Some(err),
            MyAppError::Parse(err) => Some(err),

            // The custom variants would typically return None because it 
            // does not inherently involve or reference another error
            MyAppError::OutOfRange(_) => None,
            MyAppError::InvalidNumber(_) => None,
        }
    }
}

// Simulate a function that might return various errors

fn read_and_parse_number_from_file(filename: &str) -> Result<i32, MyAppError> {
    let mut file = File::open(filename).map_err(MyAppError::Io)?;
    let mut contents = String::new();
    file.read_to_string(&mut contents).map_err(MyAppError::Io)?;

    let number: i32 = contents.trim().parse().map_err(MyAppError::Parse)?;

    // Custom logic to validate the parsed number

    if number < 0 || number > 100 {

        // Return the Custom() error type
        return Err(MyAppError::OutOfRange(OutOfRangeError { message: 
            format!("Number {} is out of the valid range (0-100).", number).into() }
        ));
    }

    if number == 50 {

        // Return the Custom() error type
        return Err(MyAppError::InvalidNumber(InvalidNumberError { message:
            "Number can not be 50.".into() }
        ));
    }


    Ok(number)
}

// fn designates a function
// Command line is not handled as a argument provided by main() 
// This main() function does not return a value
fn main() {
 
    // We just love panicking all the time
 
    // Panic
    // -----
    
    // This should never happen so should be avoided

    // Simple examples of triggering panic

    // Devide by zero
    // Disable compile checks for panic conditions
    // #[allow(unconditional_panic)]
    // let _number = 10 / 0;
    
    // Manually trigger panic
    // panic!("My panic");

    // Pirate loot sharing (this works)
    
    let _crew_share = pirate_share(10000, 2);

    // Pirate loot sharing (this panics)
    //
    // Panic is a orderly process exit. That is stack is unwound
    // and all allocations are undone prior to main() exit.
    // Recommend setting RUST_BACKTRACE=1 for this test 
    // to better visualize panic stack unwinding.
    
    // let _crew_share = pirate_share(10000, 0);

    // std::panic::catch_unwind() is not covered here

    // Example of a double panic

    let _resource = Resource;

    // We panic here triggering Drop in _resource
    // If enabled Drop() will in it's turn fail
    // Recommend setting RUST_BACKTRACE=1 for this test
    
    // panic!("Initial panic in main block");

    // Exit on first Panic by default
    //   Compile with panic=abort
    //   Cargo.toml add:
    //
    //     [profile.dev]
    //     panic = "abort"
    //
    //     [profile.release]
    //     panic = "abort"
    
    // Results
    // -------
    //
    // Rust does Not have exceptions!
    // Functions return a success result Ok([value]) or a error 
    // result Err([error]) error is a io::Error type.

    // Catching errors the verbose way
    // -------------------------------

    let valid_input = "42";
    let invalid_input = "not_a_number";

    match parse_number(valid_input) {
        Ok(number) => println!("Parsed number: {}", number),
        Err(e) => println!("Failed to parse number: {}", e),
    }

    match parse_number(invalid_input) {
        Ok(number) => println!("Parsed number: {}", number),
        Err(e) => println!("Failed to parse number: {}", e),
    }

    // Using one of the following 
    // --------------------------
    //
    //   result.is_ok()
    //   result.is_err()
   
    // To get error string
    //   result.err().unwrap()

    let result = parse_number(valid_input);
    if result.is_ok() {
        let number = result.unwrap(); // This can be safely called because we know it’s Ok
        println!("Parsed number: {}", number);
    } else {
        println!("Failed to parse number: {}", result.err().unwrap());
    }

    let result_invalid = parse_number(invalid_input);
    if result_invalid.is_err() {
        println!("Failed to parse number: {}", result_invalid.err().unwrap());
    } else {
        let number = result_invalid.unwrap(); // This can be safely called because we know it’s Ok
        println!("Parsed number: {}", number);
    }

    // Other options (see documentation)
    //   result.ok()
    //   result.err()
    //   result.unwrap_or(fallback)
    //   result.unwrap_or_else(fallback_fn)
    //   result.unwrap()
    //   result.expect(message)
   
    // Borrowing references to value in Result<T, E>
    //   result.as_ref()
    //   result.as_mut()
   
    // Result type aliase
    // ------------------
    //
    // Defintion to allow error type to be omitted in function
    // declarions. Example for example in a library of functions.
   
    match parse_number_my_result(valid_input) {
        Ok(number) => println!("Parsed number: {}", number),
        Err(e) => println!("Error: {:?}", e),
    }

    match parse_number_my_result(invalid_input) {
        Ok(number) => println!("Parsed number: {}", number),
        Err(e) => println!("Error: {:?}", e),
    }

    // Printing errors
    // ---------------
    //
    // We use already created result_invalid example

    let result_invalid = parse_number(invalid_input);

    // Normal error printout

    println!("{}", result_invalid.as_ref().err().unwrap());
    
    // Using description() (deprecated)
    // Will work when using some older Rust compilers
    //   println!("{}", result_invalid.err().description());

    // Debugging error printout "{:?}"

    println!("{:?}", result_invalid.as_ref());

    // Deprecated err.cause() method hase been replaced with .source()
    // Note: .source() will not allways provide extra information
    //       as this depends on the underlaying implementation.

    // Input that will cause a parsing error

    let input = "not_a_number";
    
    match parse_number_source(input) {
        Ok(number) => println!("Parsed number: {}", number),
        Err(e) => {
            
            // Print the top-level error message

            println!("Error: {}", e);

            // Use the source() method to find the underlying cause of the error
            
            if let Some(source) = e.source() {
                println!("Caused by: {}", source);
            } else {

                // This is expected for simple errors like ParseIntError

                println!("No underlying cause.");
            }        
        },

    }
    
    // error-chain crate for stack trace capture not covered here

    // Propagating errors '?'
    // ----------------------
    //
    // Note: Older code used the try!() macro 

    // Make sure this file does not exists and does not contains a valid integers
    let _filename = "does_not_exist.txt"; 

    // match _parse_number_from_file(_filename) {
    //     Ok(number) => println!("Parsed number: {}", number),
    //     Err(e) => println!("Error occurred: {}", e),
    // }

    // Propagating errors when working with multiple error types

    // Example above already does this:
    //    fn _parse_number_from_file() propagates Box<dyn std::error::Error>
    //        All errors are based on std::error::Error
    //    fn _read_file_to_string() propagates io::Error
    
    // error-chain crate is not covered here

    // Dealing with errors that "Can't happen"
    // Just a simple example to make a point how difficut this can be

    let digits = "red";  // Should never get this value

    // Returns Result<u64, ParseIntError> 

    // Parse fails but no panic

    let num = digits.parse::<u64>();   
 
    // Result is unusable

    println!("Parsed number: {:?}", num);   

    // Result is unusable and .unrap() fails

    // println!("Parsed number: {:?}", num.unwrap());  

    // Can not use '?' as return type is not GenResult as we are in main()
    //   let num = digits.parse::<u64>()?;   

    // Result is unusable but we can capture it with .expect()

    // println!("Parsed number: {:?}", num.expect("We have a problem"));   

    // Ignoring errors using 'let _ = '

    read_file_and_ignore("fake.txt"); 

    println!("Finished attempting to read the file, ignoring errors.");

    // Handling errors in main()
    // -------------------------

    // You can not use the `?` operator in main()
    // parse_number_my_result(invalid_input)?;

    // .expect() is one option
    // parse_number_my_result(invalid_input).expect("Conversion failed!");

    // Handle the error reporting and exit

    if let Err(_err) = parse_number_my_result(invalid_input) {
        println!("Parse number failed.");
        // std::process::exit(1);
    }

    // Declaring custom error types
    // ----------------------------

    let _filename = "number_does_not_exist.txt"; 

    match read_and_parse_number_from_file(_filename) {
        Ok(number) => println!("Parsed number: {}", number),
        Err(e) => println!("Error occurred: {}", e),
    }

    println!("This is the end.");
    
}

