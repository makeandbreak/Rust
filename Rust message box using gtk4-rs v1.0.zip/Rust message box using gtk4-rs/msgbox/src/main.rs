use gtk::prelude::*;
use gtk::{Application, ApplicationWindow, Button, MessageDialog, MessageType, ButtonsType};

fn main() {
    // Application::builder()    Initiates the construction of a new GTK application 
    // .application_id("com.example.MessageBox")    Set the application ID
    // .build();    Finalizes the builder process and returns an instance of the Application
    let app = Application::builder()
        .application_id("com.example.MessageBox") 
        .build();

    // Connect the activate signal of the Application to a specific handler function    
    app.connect_activate(build_ui);

    // Starts the application's main event loop
    app.run();
}

fn build_ui(app: &Application) {

    // ApplicationWindow::builder()  Starts the process of constructing a new ApplicationWindow  
    // .application(app)             Associates the window with the Application instance
    // .title("Message Box Example") Sets the window's title
    // .default_width(300)           Sets the initial width  
    // .default_height(100)          Sets the initial height
    // .build();                     Finalizes the process of constructing a new ApplicationWindow
    let window = ApplicationWindow::builder()
        .application(app)
        .title("Message Box Example")
        .default_width(300)
        .default_height(100)
        .build();

    // Creates a new GTK button with a label
    let button = Button::with_label("Show Message Box");

    // .set_child()   Assigns the button widget as the child (or main content) of the window
    // Some()         Wraps a reference to the button widget  
    window.set_child(Some(&button));

    // This method makes the window visible on the screen
    window.present();
    
    // Connects a callback function that will be executed when the button is clicked
    //     move |_| {}    This is a closure (anonymous function).
    //     move           closure takes ownership of any variables it captures from the surrounding environment
    //     |_|            The closure takes one argument, which is ignored here (denoted by _)
    button.connect_clicked(move |_| {

        // Creates a weak reference
        // .downgrade()    This method converts a strong reference into a weak reference
        let window_weak = window.downgrade();

        // .upgrade()    Attempts to upgrade the weak reference back to a strong reference
        // Some(window)  If the widget still exists and can be upgraded
        if let Some(window) = window_weak.upgrade() {

            // Show the message box
            show_message_box(&window);
        }
    });

 
}

fn show_message_box(parent: &ApplicationWindow) {
    
    // MessageDialog::builder()           Starts constructing a new message dialog
    // .transient_for(parent)             Sets the parent window of the dialog
    // .modal(true)                       Makes the dialog modal
    // .buttons(ButtonsType::Ok)          Adds an "OK" button to the dialog
    // .message_type(MessageType::Info)   Sets the icon and style of the dialog
    // .text("This is a message box!")    Sets the main message text 
    // .secondary_text("Additional information can go here.")     
    //     Adds supplementary text below the main message for additional details
    // .build();                          Finalizes constructing a new message dialog
    let message_dialog = MessageDialog::builder()
        .transient_for(parent)
        .modal(true)
        .buttons(ButtonsType::Ok)
        .message_type(MessageType::Info)
        .text("This is a message box!")
        .secondary_text("Additional information can go here.")
        .build();

    // .connect_response()    Sets up a signal handler for the dialog's response signal
    // |dialog, _| {}         An anonymous closure (lambda function) that takes two parameters 
    // dialog                 The dialog widget itself.
    // _                      An unused parameter representing the response ID
    message_dialog.connect_response(|dialog, _| {

        // Close dialog
        dialog.close();
    });

    // This method makes the dialog visible on the screen 
    message_dialog.present();
}