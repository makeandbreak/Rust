extern crate pkg_config;

fn main() {

    println!("cargo:rustc-link-lib=gtk-4");
    println!("cargo:rustc-link-lib=dylib=vulkan-1");
    println!("cargo:rustc-link-search={}\\lib", std::env::var("CARGO_MANIFEST_DIR").unwrap());
    println!("cargo:rustc-link-search=native=C:\\VulkanSDK\\1.4.309.0\\Lib");
    println!("cargo:rustc-link-search=native=C:\\msys64\\mingw64\\lib");
    println!("cargo:include=C:\\VulkanSDK\\1.4.309.0\\Include");

    pkg_config::Config::new()
        .probe("gtk4")
        .unwrap();

}



