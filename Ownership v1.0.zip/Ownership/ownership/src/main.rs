use std::rc::Rc;
use std::sync::Arc;

fn main() {
    

    /*
    Python

    # Python uses a copy pointer and manage reference counts strategy

    s = ['one', 'two', 'three']

    # Reference structure after above assignment
    #
    #   s -> list (PyListObject)
    #            Reference count: 1
    #            Length: 3
    #            Capacity: 4
    #            Reference to start of list elements ->
    #
    #                list elements
    #                    Reference to list element 1 ->
    #
    #                        string (PyASCIIObject)
    #                            Reference count: 1
    #                            Length: 3
    #                            String: 'one'
    #               
    #                list elements
    #                    Reference to list element 2 ->
    #
    #                        string (PyASCIIObject)
    #                            Reference count: 1
    #                            Length: 3
    #                            String: 'two'
    #    
    #                list elements
    #                    Reference to list element 3 ->
    #
    #                        string (PyASCIIObject)
    #                            Reference count: 1
    #                            Length: 4
    #                            String: 'three'

    t = s
    u = s

    # Reference structure after above assignments
    #
    #   s,t,u -> list (PyListObject)
    #            Reference count: 3
    #
    # Now all local variables point to same list and the list reference 
    # count is updated to 3

    */

    /*
    C++

    // C++ uses a 'deep copy' everything approach
    // Note: Yes, there are way to mitegate this but this is the default 
    //       behavour of C++

    using namespace std;
    vector<string> s = {"one", "two", "three"};

    /*
     
    s -> Stack frame
             Capacity: 4
             Used: 3
             Reference to heap ->

                 Heap
                     Capacity: 3
                     Used: 3
                     Reference to string 1 -> 
                         String in memory: "one" 
                   
                     Capacity: 3
                     Used: 3
                     Reference to string 2 -> 
                         String in memory: "two" 

                     Capacity: 4
                     Used: 4
                     Reference to string 3 ->  
                         String in memory: "tree"  
                    
    */

    vector<string> t = s;
    vector<string> u = s;
    
    /* 
    
    C++ will now have copied the structure referenced by s 
    under t and u.

    t -> Stack frame       Copy of s -> Stack frame
             Capacity: 4
             Used: 3
             Reference to heap -> ...

    u -> Stack frame       Copy of s -> Stack frame
             Capacity: 4
             Used: 3
             Reference to heap -> ...

    */

    */

    
    // Rust

    // Rust uses a concept of unique owner and transfer of that ownership 
    // under predefined conditions. When ownership is transferred the 
    // original owner not only loses ownership but the reference to the
    // target object in question.

    let s = vec!["one".to_string(), "two".to_string(), "three".to_string()];

    /*
     
    s -> Stack frame
             Capacity: 4
             Used: 3
             Reference to heap ->

                 Heap
                     Capacity: 3
                     Used: 3
                     Reference to string 1 -> 
                         String in memory: "one" 
                   
                     Capacity: 3
                     Used: 3
                     Reference to string 2 -> 
                         String in memory: "two" 

                     Capacity: 4
                     Used: 4
                     Reference to string 3 ->  
                         String in memory: "tree"  
                    
    */     

    let _t = s;

    /*
     
    s -> is now uninitialized
    t -> Stack frame
             Capacity: 4
             Used: 3
             Reference to heap ->

                 Heap
                     Capacity: 3
                     Used: 3
                     Reference to string 1 -> 
                         String in memory: "one" 
                   
                     Capacity: 3
                     Used: 3
                     Reference to string 2 -> 
                         String in memory: "two" 

                     Capacity: 4
                     Used: 4
                     Reference to string 3 ->  
                         String in memory: "tree"  
                    
    */  
    
    // s is now uninitialized can no longer be used 
    // Compile error: error[E0382]: use of moved value: 's'

    //let u = s;   // Remove '//' to build code and see error


    // I hate this give me the same behavour as in C++

    let s = vec!["one".to_string(), "two".to_string(), "three".to_string()];
    let _t = s.clone();
    let _u = s.clone();


    // Some more instances where we see move

    struct Person { _name: String, _birth: i32 }

    // Returning values from a function
    //   Ownership move 'Vec::new()' -> 'composers'

    let mut composers = Vec::new();
    
    // Returning values from a function
    //    '"Jason".to_string()' -> String instance

    // Constructing new values
    //    String instance -> name

    // Passing values to a function 
    //    Person -> Vectors push method 
    
    composers.push(Person { _name: "Jason".to_string(), _birth: 1525 });

    // Move and control flow

    let c = false;
    let _x = vec![10, 20, 30];

    // Remove '//' to build code and see errors
    if c {
        //_own_it1(_x);  // Will take ownership of x
    } else {
        //_own_it2(_x);  // Will take ownership of x
    };
    //_lost_it(_x);   

    /* Remove comment out '/*' '*/' to build

    let x2 = vec![10, 20, 30];

    while true {
        _own_it1(x2);  // Will take ownership of x on first loop
    }

    */

    // Moves and indexed content

    // Build a vector of the strings "101", "102", ... "105"
    let mut v = Vec::new();
    for i in 101 .. 106 {
        v.push(i.to_string());
    }

    // Pull out random elements from vector
    
    // Indexed content elements can not be uninitialized so ownership swap fails
    // Generates -> error[E0507]: cannot move out of index of `Vec<String>`
    //let _third = v[2];
    //let _fifth = v[4];

    // Working alternatives that do not uninitialize content elements

    // 1. Pop a value of the end of the vector
    let fifth = v.pop().unwrap();
    println!("{}", fifth);

    // 2. Move a value out of the middle of the vector, and move the last
    //    element into it's spot:
    let second = v.swap_remove(1);
    println!("{}", second);

    // 3. Swap in another value for the one we're taking out:
    let third = std::mem::replace(&mut v[2], "substitute".to_string());
    println!("{}", third);

    // Lets see what's left in out vector

    println!("{:?}", v);

    // Loop over all values

    let v2 = vec!["one".to_string(),
                  "two".to_string(),
                  "three".to_string()];

    // for loop takes ownership of v2 and extracts
    // one value at a time into the loop (s2) and
    // the value is mutable.

    for mut s2 in v2 {
        s2.push('!');
        println!("{}", s2);
    }

    // Using Option<> to make a element removable

    struct Dog { _name: Option<String>, _birth: i32 }

    let mut dogs = Vec::new();
    dogs.push( Dog { _name: Some("winston".to_string()), _birth: 2024});

    // Now we can take it
    let first_name = dogs[0]._name.take();
    
    // We unwrap() as responce is Some("winston".to_string())
    println!("{:?}", first_name.unwrap());

    // Name has been taken so now name in struct [0] is None
    println!("{:?}", dogs[0]._name);

    // Copy types: The exception to moves
    //   The standard Copy types include all the machine integer and floating-point numeric
    //   types, the char and bool types and a few others. A tuple or fixed size array of Copy
    //   types is itself a Copy type.
    //   Only types for wich a simple bit-for-bit copy suffices can be Copy.

    // Type i32 is a Copy type

    let num1: i32 = 36;

    // num1 is copied to num2
    let num2 = num1;

    println!("{}", num1);
    println!("{}", num2);

    // Forcing a user defined type with Copy types to allow copy

    #[derive(Copy, Clone)]
    struct Label { number: u32}

    let label1 = Label {number: 1};
    let label2 = label1;
 
    println!("{}", label1.number);
    println!("{}", label2.number);

    // But I like Python:s reference count model

    // Rc and Arc (thread safe): Shared ownership

    // Using Rc

    let ref_s: Rc<String> = Rc::new("Hello ref".to_string());
    let _ref_t: Rc<String> = ref_s.clone();
    let _ref_u: Rc<String> = ref_s.clone();

    // A value owned by a Rc or Arc pointer is immutable

    //ref_u.push_str("World");

    // Above will cause:
    //   error[E0596]: cannot borrow data in an `Rc` as mutable

    // Normal ownership rules still apply to the actual Rc or Arc pointers 

    // Using Arc

    let ref_s_arc: Arc<String> = Arc::new("Hello ref".to_string());
    let _ref_t_arc: Arc<String> = ref_s_arc.clone();
    let _ref_u_arc: Arc<String> = ref_s_arc.clone();

    // There are additional methods to enable interior mutability and
    // protect against reference-counting loops not covered here

}

fn _own_it1(x: Vec<u8>){
    println!("{:?}", x);
}

fn _own_it2(x: Vec<u8>){
    println!("{:?}", x);
}

fn _lost_it(x: Vec<u8>){
    println!("{:?}", x);
}
