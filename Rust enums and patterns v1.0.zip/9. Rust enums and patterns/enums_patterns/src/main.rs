
mod use_module_enum {

    // Referencing module enum

    enum _MyPets {
        Dog,
        Cat,
        Bird
    }

    #[allow(unused_imports)]
    use self::_MyPets::*;

}

#[macro_use]
extern crate num_derive;

use num_traits::{FromPrimitive, ToPrimitive}; // Trait for conversion

#[derive(Debug, PartialEq, FromPrimitive, ToPrimitive)]
enum Color {
    Red = 1,
    Green = 2,
    Blue = 3,
}

// fn designates a function
// Command line is not handled as a argument provided by main() 
// This main() function does not return a value
fn main() {

    // println!() is a macro as designated with "!"
    println!("This is the start!");

    // Enums basic example 

    enum _MyOrdering {
        Less,
        Equal,
        Greater
    }

    // Many enums are defined in standard library 

    use std::cmp::Ordering;

    // use imported level only

    fn _compare_1(n: i32, m: i32) -> Ordering {
        if n <m {
            Ordering::Less
        } else if n > m {
            Ordering::Greater
        } else {
            Ordering::Equal
        }
    }

    // use imported level and children

    use std::cmp::Ordering::*;

    fn _compare_2(n: i32, m: i32) -> Ordering {
        if n <m {
            Less
        } else if n > m {
            Greater
        } else {
            Equal
        }
    }

    // Numbering of enums starts from 0 and is of a integer type
    // We can override this

    enum MyComError {
        _BadSerial = 333,
        _BadParallel = 222,
        _BadNetwork = 111
    }

    // How about size in memory (Rust will go for the least number of bytes)

    use std::mem::size_of;

    assert_eq!(size_of::<Ordering>(), 1);
    assert_eq!(size_of::<MyComError>(), 2);

    // Casting enum

    assert_eq!(MyComError::_BadParallel as i32, 222);

    // Casting to enum from a integer type is however not supported

    // Converting integer value to a selected enum

    fn _my_com_error_from_u32(n: u32) -> Option<MyComError> {
        match n {
            333 => Some(MyComError::_BadSerial),
            222 => Some(MyComError::_BadParallel),
            111 => Some(MyComError::_BadNetwork),
            _ => None
        }
    }

    // Same but using crates num-derive along with num-traits
    //   See declaration above main()

    // Convert from an integer to an enum

    if let Some(color) = Color::from_i32(1) {
        println!("Color from integer: {:?}", color); // Outputs: Color from integer: Red
    } else {
        println!("No matching color found.");
    }

    // Convert from enum to integer

    if let Some(green_value) = Color::Green.to_i32() {
        println!("Integer value of Green: {}", green_value); // Outputs: Integer value of Green: 2
    } else {
        println!("Could not convert color to an integer.");
    }
  
    // You can implement features as needed
    
    #[derive(Copy, Clone, Debug, PartialEq)]
    #[allow(dead_code)]
    enum TimeUnit {
        Seconds, Minutes, Hours, Days, Months, Years 
    }

    // Enums can have methods, just like structs

    impl TimeUnit {
        
        // Return the unit of this specific time unit
        
        fn name(self) -> &'static str {
            match self {
                TimeUnit::Seconds => "Seconds",
                TimeUnit::Minutes => "Minutes", 
                TimeUnit::Hours => "Hours", 
                TimeUnit::Days => "Days", 
                TimeUnit::Months => "Months", 
                TimeUnit::Years => "Years" 
            }
        }

        // Return the element of this specific time unit

        fn element(self) -> &'static str {
            self.name().trim_end_matches('s')
        }

    }

    // Using TimeUnit

    let time_unit = TimeUnit::Hours;
 
    println!("Name: {}", time_unit.name());
    println!("Element: {}", time_unit.element()); 

    // Enum with Data

    // A timestamp that has been deliberately rounded off, so our program
    // says "6 months ago" instead of "February 9, 2016, at 9:49 AM"
    //
    // InThePast     Tuple variant   Function that creates a new RoughTime value
    // InTHeFuture   Tuple variant   Function that creates a new RoughTime value
    #[derive(Copy, Clone, Debug, PartialEq)] 
    #[allow(dead_code)]
    enum RoughTime {
        InThePast(TimeUnit, u32),
        JustNow,
        InTheFuture(TimeUnit, u32)
    }

    // Using InThePast and InTHeFuture

    let _four_score_and_seven_years_ago = 
        RoughTime::InThePast(TimeUnit::Years, 4*20 + 7);

    let _three_hours_from_now = 
        RoughTime::InTheFuture(TimeUnit::Hours, 3);
    
    // Using struct variants in enums

    #[allow(dead_code)]
    struct Point3d {x: f32, y: f32, z: f32}

    const ORIGIN:Point3d = Point3d {x:0.0, y:0.0, z:0.0}; 

    #[allow(dead_code)]
    enum Shape {
        Sphere { center: Point3d, radius: f32 },
        Coboid { corner1: Point3d, corner2: Point3d },
    }

    let _unit_sphere = Shape::Sphere { center: ORIGIN, radius: 1.0};

    // We have three kinds of enum variant:
    //     Variants with no data correspond to unit-like structs
    //     Tuble variants look and function like tuple structs
    //     Struct variants have curly braces and named fields
    
    // A single enum can have variants of all three types
    //   All contructors and fields of a public enum are automatically public

    #[allow(dead_code)]
    enum DevelopmentStatus {
        Unknown,
        Ongoing,
        ItsComplicated(Option<String>),
        ItsExtremelyComplicated {
            complexity: u32,
            expense: f32 
        }
    }

    // Enums and memory
    
    // In memory, enums with data are stored as a small integer tag, plus 
    // enough memory to hold all the fields of the largest variant. The tag 
    // field is for Rust's internal use. It tells which contructor created 
    // the value, and therefore which fields it has.
    // The tag may in some instances be optimized away by the Rust compiler.

    // Rich data structures using enums

    // All fields used to encode JSON data

    use std::collections::HashMap;

    #[allow(dead_code)]
    enum Json {
        Null,
        Boolean(bool),
        Number(f64),
        String(String),
        Array(Vec<Json>),
        Object(Box<HashMap<String, Json>>),
    }

    // Generic enums

    #[allow(dead_code)]
    enum GenOption<T> {
        None,
        Some(T)
    }

    #[allow(dead_code)]
    enum GenResult<T, E> {
        Ok(T),
        Err(E)
    }

    // Generic data structures

    // An ordered collection of 'T's

    #[allow(dead_code)]
    enum BinaryTree<T> {
        Empty,
        NonEmpty(Box<TreeNode<T>>)
    }

    // A part of a BinaryTree

    #[allow(dead_code)]
    struct TreeNode<T> {
        element: T,
        left: BinaryTree<T>,
        right: BinaryTree<T>
    }

    // Create some parts

    use BinaryTree::*;

    // Note: For more advanced cases design using a Box or some other type 
    //       of smart pointer when creating references

    #[allow(dead_code)]
    let jupiter_tree = NonEmpty(Box::new(TreeNode {
        element: "jupiter",
        left: Empty,
        right: Empty
    }));

    #[allow(dead_code)]
    let mercury_tree = NonEmpty(Box::new(TreeNode {
        element: "mercury",
        left: Empty,
        right: Empty
    }));

    // Larger trees can be built from smaller ones
    // _mars_tree as root

    let _mars_tree = NonEmpty(Box::new(TreeNode {
        element: "Mars",
        left: jupiter_tree,
        right: mercury_tree
    }));
    
    // let element_field = _mars_tree.element;    // unknown field on compile
    // let element_field = _mars_tree.NonEmpty.element;   // unknown field on compile
    // let element_field = _mars_tree.0;   // unknown field on compile
    // ...other patterns trying to access field directly will also fail

    // Patterns

    // Simplest example matching only on enum values 
    // See documentation for all options in addition to this presentation

    fn rough_time_to_english(rt: RoughTime) -> String {
        match rt {
            RoughTime::InThePast(units, count) => 
                format!("{} {} ago", count, units.element() ),
            RoughTime::JustNow => 
                format!("just now"),
            RoughTime::InTheFuture(units, count) => 
                format!("{} {} ago", count, units.element() )
        }
    }

    println!("{}", rough_time_to_english(_four_score_and_seven_years_ago));
    println!("{}", rough_time_to_english(_three_hours_from_now));

    // Literals, variables, and wildcards as patterns

    use rand::Rng; // Import the Rng trait for random number generation

    struct Meadow;

    impl Meadow {
    
        fn count_rabbits(&self) -> u8 {

            // Create a random number generator
    
            let mut rng = rand::thread_rng();
    
            // Generate a random number in the range [0, 5]
    
            rng.gen_range(0..=5)
        }
    
    }
    
    let meadow = Meadow;
    
    let rabbit_count = meadow.count_rabbits();
    
    println!("Number of rabbits in the meadow: {}", rabbit_count);

    // Pattern match the value of rabbit_count

    match rabbit_count {
        0 => {}  // nothing to say
        1 => println!("A rabbit is nosing around in the clover"),
        n => println!("There are {} rabbits hopping about in the meadow", n)
    }

    // You can also match on a string

    #[derive(Debug)]
    enum Calender {
        Gregorian,
        Chinese,
        Ethopian,
        Roman
    }

    // We add this section for clarity

    #[derive(Debug)]
    struct Settings {
        calendar: String
    }

    impl Settings {

        // Constructor to initialize with default values

        fn new() -> Self {
            Self {
                calendar: String::new(),
            }
        }

        // Getter: retrieves the value of the field based on name

        fn get_field(&self, field_name: &str) -> Option<&str> {
            match field_name {
                "calendar" => Some(&self.calendar),
                _ => None,
            }
        }

        // Setter: sets the value of the field based on name

        fn set_field(&mut self, field_name: &str, value: &str) {
            match field_name {
                "calendar" => self.calendar = value.to_string(),
                _ => println!("Unknown field: {}", field_name),
            }
        }

    }

    fn parse_error(requested_field: &str, other_field: &str) {
         println!("Requested field: {} actual {}", requested_field, other_field );
    }

    let mut settings = Settings::new();

    // Using setter
    
    // Normal

    // settings.set_field("calendar", "chinese");
    
    // Special case

    // settings.set_field("calendar", "roman");

    // Does not exist case

    settings.set_field("calendar", "Unknown");
 
    // Using getter
    
    println!("Calendar: {:?}", settings.get_field("calendar"));

    // Now for the example

    let _special_calendar_name = "roman";

    let calender = 
        match settings.get_field("calendar") {
            Some("gregorian") => Calender::Gregorian,
            Some("chinese") => Calender::Chinese,
            Some("ethopian") => Calender::Ethopian,

            // Using a variable to match

            // Example 1: This will not work
            //
            // Why it doesn't work:
            //
            // In Rust's match, pattern variables (like Some(special_calendar_name)) 
            // shadow the outer variable of the same name.
            // 
            // Here, Some(special_calendar_name) will match any value, binding it 
            // to the new variable special_calendar_name local to that pattern, 
            // not the outer one.
            //
            // The outer special_calendar_name = "roman" is NOT used in this match 
            // clause; instead, the pattern matches any value and binds it to the 
            // inner variable.
            //
            // Result:
            //
            // Regardless of the settings.get_field("calendar") value, if it is 
            // Some(something), it will match the last pattern and return 
            // Calender::Roman.
            //
            // The outer variable _special_calendar_name remains unaffected.

            // Some(_special_calendar_name) => Calender::Roman,

            // Example 2: Use a if-statement to capture case (and end matching here)

            // Some(calendar_name) => {
            //     if calendar_name == _special_calendar_name {
            //         Calender::Roman
            //     } else { parse_error("calendar", calendar_name);
            //              Calender::Gregorian // Use this default value if no ther found
            //            }
            // },

            // Example 3: Do not let execution of pattern logic if not correct name
            //            In this example if... is a pattern guard

            Some(calendar_name) if calendar_name == _special_calendar_name => Calender::Roman,

            // Use this to capture unknown requested calender name:
            // Note: Can not be used with Example 2
            
            // other => {parse_error("calendar", other.expect("Fatal error!"));
            //           Calender::Gregorian // Use this default value if no ther found
            //          }        

            // Use this to ignoring unknown requested calender name:
            // Note: Can not be used with Example 2

            _ => {parse_error("calendar", "Unknown");
                  Calender::Gregorian // Use this default value if no ther found
                 }        
        };

    println!("Calendar: {:?}", calender);

    // Tuple amd struct patterns

    // Tuple pattern - Where is my point?  

    fn _describe_point(x: i32, y: i32) -> &'static str {
        
        use std::cmp::Ordering::*;

        match (x.cmp(&0), y.cmp(&0)) {
            (Equal, Equal) => "at the origin",
            (_, Equal) => "on the x axis",
            (Equal, _) => "on the y axis",
            (Greater, Greater) => "in the first quadrant",
            (Less, Greater) => "in the second quadrant",
            _ => "somewhere else"
        }

    }

    // Struct pattern - Let's fly!

    #[derive(Debug)]
    struct Point {
        x: i32,
        y: i32,
    } 

    #[derive(Debug)]
    struct Balloon {
        pub location: Point
    }

    let balloon = Balloon {
        location: Point {x:200, y:300}
    };

    match balloon.location {
        Point { x: 0, y: height } =>
            println!("straight up {} meters", height),
        Point { x, y } =>
            println!("at ({}m, {}m)", x, y)
    }

    // How to pattern match on selected fields only?

    #[derive(Debug)]
    #[allow(dead_code)]
    // struct ManyFields<'a> {
    struct ManyFields {
        field1: i32,
        
        // field2: &'a str,
        field2:String,

        field3: u32,
        field4: f32,
        field5: u16
    } 

    let mut many_fields = ManyFields {
        field1: 2,
        field2: "Text".to_string(),
        field3: 3,
        field4: 4.4,
        field5: 5
    };

    match many_fields {

        ManyFields {
            field1: _,    // Ignore this field
            field2: _,    // Ignore this field
            field3: 3,
            field4: _,    // Ignore this field
            field5: 5

        } => println!("Found"), 

        _ => println!("Not found")
    }

    // Like this also works

    match many_fields {

        ManyFields {
            field3: 3,
            field5: 5, ..

        } => println!("Found"), 

        _ => println!("Not found")
    }

    // Reference patterns
    //   Avoid moving values

    // We use local variables to modify values

    println!("Before match and modification");
    println!(" field1 {}", many_fields.field1);
    println!(" field2 {}", many_fields.field2);
    println!(" field3 {}", many_fields.field3);
    println!(" field4 {}", many_fields.field4);
    println!(" field5 {}", many_fields.field5);

    match many_fields {

        ManyFields {

            field1:2,   // Filter on this field
            ref mut field2,  // We grap this by reference to avoid move issue
            ref mut field3,  // We grap this by value
            // field4:   Ignore this field
            ref mut field5,  // We grap this by value
            ..           // Informs Rust to ignore fields not listed (field1 and field4)

        } => {
              println!("Found");
              println!(" field2 {}", field2);    // Print all used fields
              println!(" field3 {}", field3);
              println!(" field5 {}", field5);

              // Modify 

              field2.push_str(" modified");    

              *field3 = 4;

              *field5 = 6;
             }, 

        _ => println!("Not found")  
    }

    println!("After match and modification");
    println!(" field1 {}", many_fields.field1);
    println!(" field2 {}", many_fields.field2);
    println!(" field3 {}", many_fields.field3);
    println!(" field4 {}", many_fields.field4);
    println!(" field5 {}", many_fields.field5);

    // Using & pattern to get a pointer 

    // Example to access char in a String

    let mut chars = many_fields.field2.chars().peekable();

    match chars.peek() {
        Some(&c) => println!("Coming up : {:?}", c),
        None => println!("end of chars")
    }

    // Matching multiple possibilities
    //  '|' OR for patterns

    let _at_end =
        match chars.peek() {
            Some(&'\r') | Some(&'\n') |None => true,
            _ => false
        };
    
    // Using ranges
    //   [value1]..=[value2]    Includes value1 to value2
    //   [value1]..[value2]     Includes value1 up to but not including value2
    // Note: This has been depreciated
    //   [value1]...[value2]     Includes value1 up to but not including value2
    
    match chars.peek().unwrap() {
        '0' ..= '9' => 
            println!("Is a number"),
        'a' ..= 'z' | 'A' ..= 'Z' => 
            println!("Is a letter"),
        ' ' | '\t' | '\n' => 
            println!("Is a whitespace"),
        _ => println!("Is punctuation")        
    }

    // @ patterns

    fn describe_number(num: i32) {
        match num {
            // Bind the value to `n` while also matching the pattern
            n @ 1..=10 => println!("{} is between 1 and 10", n),
            n @ 11..=20 => println!("{} is between 11 and 20", n),
            _ => println!("{} is outside the target range", num),
        }
    }

    let numbers = vec![3, 15, 25, 8, 12, 30];

    for number in numbers {
        describe_number(number);
    }

    // Where patterns are allowed 

    // Example 1:Unpack a struct into three new local variables
    
    //   let Track { album, track_number, title, .. } = song;

    // Full example including the above

    #[allow(dead_code)]
    struct Track {
        album: String,
        track_number: u32,
        title: String,
        artist: String,
        genre: String,
    }

    // Create a Track instance
    
    let song = Track {
        album: "The Dark Side of the Moon".to_string(),
        track_number: 3,
        title: "Time".to_string(),
        artist: "Pink Floyd".to_string(),
        genre: "Progressive Rock".to_string(),
    };

    // Original destructuring snippet

    let Track { album, track_number, title, .. } = song;

    // Print the unpacked values
    
    println!("Album: {}", album);
    println!("Track Number: {}", track_number);
    println!("Title: {}", title);

    // Other fields were ignored
    // This would fail to compile if uncommented because 'artist' was moved:
    // println!("Artist: {}", song.artist);

    // Example 2:Unpack a function argument that's is a tuple

    //   fn distance_to( (x, y): (f64, f64)) -> f64 { ... }

    // Full example including the above

    fn distance_to((x, y): (f64, f64)) -> f64 {
        (x.powi(2) + y.powi(2)).sqrt()
    }

    // Create some points as tuples

    let point_a = (3.0, 4.0);
    let point_b = (5.0, 12.0);
    let point_c = (8.0, 15.0);

    // Calculate distances using our function

    let dist_a = distance_to(point_a);
    let dist_b = distance_to(point_b);
    let dist_c = distance_to(point_c);

    // Print results

    println!("Distance from origin to point A(3,4): {:.2}", dist_a);
    println!("Distance from origin to point B(5,12): {:.2}", dist_b);
    println!("Distance from origin to point C(8,15): {:.2}", dist_c);

    // Show tuple destructuring in a let binding

    let (x, y) = point_c;
    println!("Point C coordinates: x = {}, y = {}", x, y);

    // Example 3:Iterate over keys and values of a HashMap

    //    for (id, document) in &cache_map {
    //        println!("Document #(): {}", id, document.title);
    //    }

    // Full example including the above

    // Define a Document struct
    
    struct Document {
        title: String,
        content: String,
    }

    impl Document {
    
        // Constructor for easier creation
    
        fn new(title: &str, content: &str) -> Self {
            Document {
                title: title.to_string(),
                content: content.to_string(),
            }
        }
    }

    // Create a HashMap to store documents
    
    let mut cache_map = HashMap::new();
    
    // Insert some documents

    cache_map.insert(1, Document::new("Rust Guide", "Introduction to Rust programming"));
    cache_map.insert(2, Document::new("Ownership", "Understanding ownership in Rust"));
    cache_map.insert(3, Document::new("Concurrency", "Parallel programming with Rust"));
    cache_map.insert(4, Document::new("Collections", "Common Rust collections"));

    // Iterate over keys and values
    
    println!("Cached documents:");
    
    for (id, document) in &cache_map {
        println!("Document #{}: {}", id, document.title);
    }

    // Additional example: Find a specific document

    let search_id = 2;
    
    if let Some(doc) = cache_map.get(&search_id) {
        println!("\nDocument #{} details:\nTitle: {}\nContent: {}", 
                 search_id, doc.title, doc.content);
    }

    // Example 4: Automatically dereference an argument to a closure

    //    let sum = numbers.fold(0, |a, &num| a + num);

    // Full example including the above

    // Create a vector of numbers

    let numbers = vec![10, 20, 30, 40, 50];

    println!("Original numbers: {:?}", numbers);

    // Sum using fold with automatic dereferencing
    
    let sum = numbers.iter().fold(0, |a, &num| a + num);

    println!("Sum with dereference pattern: {}", sum);

    // Alternative approaches for comparison:
    
    // 1. Without dereference pattern (explicit dereference)
    
    let sum_explicit = numbers.iter().fold(0, |a, num| a + *num);

    println!("Sum with explicit dereference: {}", sum_explicit);
    
    // 2. Using values directly (consumes the vector)
    
    let sum_owned = numbers.into_iter().fold(0, |a, num| a + num);

    println!("Sum with owned values: {}", sum_owned);

    // Refutable patterns
    
    // Example 1: 

    // Handle just one enum variant specially
    //   if let RoughTime::InTheFuture(_, _) = user.date_of_birth() {
    //       user.set_time_traveler(true);
    //   }

    // Full example including the above

    // Simple User struct with birth time and time-traveler flag

    #[derive(Debug)]
    struct User {
        birth_time: RoughTime,
        is_time_traveler: bool,
    }

    impl User {
        fn new(birth_time: RoughTime) -> Self {
            User { birth_time, is_time_traveler: false }
        }
        
        fn date_of_birth(&self) -> RoughTime {
            self.birth_time
        }
        
        fn set_time_traveler(&mut self, value: bool) {
            self.is_time_traveler = value;
        }
    }

    // Create example time instances
    
    let four_score_and_seven_years_ago = 
        RoughTime::InThePast(TimeUnit::Years, 4*20 + 7);
    
    let three_hours_from_now = 
        RoughTime::InTheFuture(TimeUnit::Hours, 3);
    
    // Create test users
    
    let mut user_a = User::new(four_score_and_seven_years_ago);
    let mut user_b = User::new(three_hours_from_now);
    let mut user_c = User::new(RoughTime::JustNow);
    
    // Check and mark time travelers
    
    for (i, user) in [&mut user_a, &mut user_b, &mut user_c].iter_mut().enumerate() {
        if let RoughTime::InTheFuture(_, _) = user.date_of_birth() {
            user.set_time_traveler(true);
        }
        println!("User {}: {:?}", i + 1, user);
    }

    // Example 2: 

    // Run some code only if a table lookup succeeds
    //   if let Some(document) = cache_map.get(&id) {
    //       return send_cached_response(document);
    //   }

    // Full example including the above

    fn send_cached_response(document: &str) {
        println!("Serving cached document: {}", document);
    }

    fn generate_and_send_response(id: u32) {
        println!("Generating new response for ID: {}", id);
        // In a real implementation, this would generate and send the actual response
    }

    // Create a cache map with some sample data

    let mut cache_map = HashMap::new();
    
    cache_map.insert(42, "Answer to everything");
    cache_map.insert(100, "Century document");

    // Test with IDs that exist and don't exist in cache
    
    let ids = [42, 7, 100];
    
    for id in ids {
        println!("\nProcessing ID: {}", id);
        
        // The original snippet - handles cache hits
    
        if let Some(document) = cache_map.get(&id) {
            send_cached_response(document);
            continue;  // Skip to next ID after cache hit
        }
        
        // Handle cache misses
    
        generate_and_send_response(id);
    }

    // Example 3: 

    // Repeatadly try something until it succeeds
    //   while let Err(err) = present_cheesy_anti_robot_task() {
    //     log_robot_attemp(err):
    //     // let the user try again (it might still be human)
    //   }

    // Full example including the above
   
    use std::io::{self, Write};

    // Simple CAPTCHA implementation

    fn present_cheesy_anti_robot_task() -> Result<(), String> {
        let secret_number = rand::thread_rng().gen_range(1..=10);
        println!("Please enter the number {} to prove you're human: ", secret_number);
        
        let mut input = String::new();
        io::stdin().read_line(&mut input).map_err(|e| e.to_string())?;
        
        let entered: u32 = input.trim().parse().map_err(|_| "Invalid number format".to_string())?;
        
        if entered == secret_number {
            Ok(())
        } else {
            Err(format!("Entered {} but expected {}", entered, secret_number))
        }
    }

    fn log_robot_attempt(err: &str) {
        println!("🤖 Robot attempt detected: {}", err);
    }

    println!("=== Human Verification System ===");
    let mut attempts = 0;
    
    // Original snippet - retry until success
    while let Err(err) = present_cheesy_anti_robot_task() {
        attempts += 1;
        log_robot_attempt(&err);
        println!("Attempt #{}. Please try again!", attempts);
    }
    
    println!("✅ Verification successful! You may proceed.");

    // Example 4: 

    // Manually loop over an iterator
    //   while let Some(_) = lines.peek() {
    //     read_paragraph(&mut lines);
    //   }
    
    // Full example including the above

    // Log failed attempts

    fn log_robot_attempt2(err: String) {
        eprintln!("⚠️  Failed attempt: {}", err);
    }

    // Present captcha challenge to user

    fn present_cheesy_anti_robot_task2() -> Result<(), String> {
        print!("🤖 Prove you're human (type 'human'): ");
        io::stdout().flush().unwrap();
        
        let mut input = String::new();
        io::stdin().read_line(&mut input)
            .map_err(|e| format!("Input error: {}", e))?;
        
        match input.trim().to_lowercase().as_str() {
            "human" => Ok(()),
            _ => Err("Incorrect response".to_string())
        }
    }

    println!("🔒 Anti-robot verification");
    
    // Retry until successful verification
    while let Err(err) = present_cheesy_anti_robot_task2() {
        log_robot_attempt2(err);
        println!("🔄 Please try again...");
    }
    
    println!("✅ Verification successful! Welcome human.");

    // Populating a binary tree

    impl<T: Ord> BinaryTree<T> {
        fn add(&mut self, value: T) {
            match *self {
                BinaryTree::Empty =>
                    *self = BinaryTree::NonEmpty(Box::new(TreeNode {
                       element: value,
                       left: BinaryTree::Empty,
                       right: BinaryTree::Empty  
                    })),
                BinaryTree::NonEmpty(ref mut node) =>
                    if value <= node.element  {
                        node.left.add(value);  
                    } else {
                        node.right.add(value);
                    }
            }
        }
    }

    let mut tree = BinaryTree::Empty;

    tree.add("Mercury");
    tree.add("Venus");

    println!("This is the end!");
}
