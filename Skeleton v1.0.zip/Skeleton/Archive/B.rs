Include "AMOS_Includes.h"
Include "Version.h"


fn main() {
    
    println!("Hello World!");
}