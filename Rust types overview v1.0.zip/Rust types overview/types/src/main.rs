
// Define all types
fn _build_vector() -> Vec<i16> {
    let mut v: Vec<i16> = Vec::<i16>::new();
    v.push(10i16);
    v.push(10i16);
    v
}

// Let compiler infer all types
// If You do not define "correct" key root object type(s) compilation
// will fail as infer will also fail
fn _build_vector_infer() -> Vec<i16> {
    let mut v = Vec::new();
    v.push(10);
    v.push(10);
    v
}

// Takes a slice reference
fn print(n: &[f64]){
    for elt in n {
        println!("{}", elt);
    }
}

fn main() {
    println!("Hello, types!");
    println!("");

    // Machine Types

    let _u8: u8 = 0;  // size (bits) 8
    println!("u8 max {}", std::u8::MAX);
    println!("u8 min {}", std::u8::MIN);
    let _i8: i8 = 0;  
    println!("i8 max {}", std::i8::MAX);
    println!("i8 min {}", std::i8::MIN);

    println!("");

    let _u16: u16 = 0;  // size (bits) 16
    println!("u16 max {}", std::u16::MAX);
    println!("u16 min {}", std::u16::MIN);
    let _i16: i16 = 0;  
    println!("i16 max {}", std::i16::MAX);
    println!("i16 min {}", std::i16::MIN);

    println!("");

    let _u32: u32 = 0;  // size (bits) 32
    println!("u32 max {}", std::u32::MAX);
    println!("u32 min {}", std::u32::MIN);
    let _i32: i32 = 0;  
    println!("i32 max {}", std::i32::MAX);
    println!("i32 min {}", std::i32::MIN);

    println!("");

    let _u64: u64 = 0;  // size (bits) 64
    println!("u64 max {}", std::u64::MAX);
    println!("u64 min {}", std::u64::MIN);
    let _i64: i64 = 0;  
    println!("i64 max {}", std::i64::MAX);
    println!("i64 min {}", std::i64::MIN);

    println!("");

    let _f32: f32 = 0.0;  // size (bits) 32
    println!("f32 max {}", std::f32::MAX);
    println!("f32 min {}", std::f32::MIN);
    let _f64: f64 = 0.0;  // size (bits) 64
    println!("f64 max {}", std::f64::MAX);
    println!("f64 min {}", std::f64::MIN);

    println!("");

    let _usize: usize = 0;  // size (bits) machine word
    println!("usize max {}", std::usize::MAX);
    println!("usize min {}", std::usize::MIN);
    let _isize: isize = 0;  // size (bits) machine word
    println!("isize max {}", std::isize::MAX);
    println!("isize min {}", std::isize::MIN);

    // Loop around

    let mut x = std::isize::MIN;
    
    println!("isize loop around {}", x.wrapping_sub(1));  // or wrapping_add()
    
    // Assign a type to a constant numbers

    x = 32isize + -32isize;

    println!("x {}", x);

    // 0x, 0o and 0b designate hexidecimal, octal and binary literals
    
    x = 0xffisize;

    println!("x hexidecimal {:x}", x);

    x = 0o105isize; 

    println!("x octal {:o}", x);

    x = 0b10011isize;

    println!("x binary {:b}", x);

    // Example of using '_' for clarity

    x = 123_456_isize;

    println!("x {}", x);

    // Byte character-like literals for the type u8
    // Only supports ASCII

    let byte_lit = b'A';

    println!("byte_lit {}", byte_lit);

    let single_quote = b'\'';

    println!("single_quote {}", single_quote);

    let backslash = b'\\';

    println!("backslash {}", backslash);

    let newline = b'\n';

    println!("newline {}", newline);

    let carrage_return = b'\r';

    println!("carrage_return {}", carrage_return);

    let tab = b'\t';

    println!("tab {}", tab);

    // As hex

    let hex_lit = b'\x1b';

    println!("hex_lit {}", hex_lit);

    // Integer type conversion

    let _number_as:i16 = 23u8 as i16;
    
    println!("_number_as {}", _number_as);

    // Truncating
    
    println!("_number_trunk {}", 0xffffffffu32);

    let _number_trunk:u16 = 0xffffffffu32 as u16;

    println!("_number_trunk {}", _number_trunk);

    // A few examples of many methods available for types (see documentaion for full list)

    println!("pow() {}", 2u8.pow(2));
    println!("abs() {}", (-2i8).abs());
    println!("abs() this will not work as () needed {}", -2i8.abs());

    // Cases where type inference may be unclear

    let _odd1 = -1.5625;  // f32 or f64
    let _odd2 = 2.;  // u?, i? or f??
    let _odd3 = 1e4;  // u16, i16,...?? 

    // Will not compile as unknown what specific fxx type '2.0' represents
    // _add4 = (2.0).sqrt();
    // Infered type 'float' has no sqrt() method

    // A few ways to get info on type infered during runtime (without the need to trigger runtime errors)
    
    dbg!(_odd1);  // May or may not print type suffix depending in Rust version used 'nn.nnn<type>'
    print_type_of(&_odd1);  // This will work for most cases. As no type specified in this case it will defualt to f64 

    // The boolean type

    let mut boolean_as_integer = false as i32;

    println!("boolean_as_integer (false) {}", boolean_as_integer);

    boolean_as_integer = true as i32;

    println!("boolean_as_integer (true) {}", boolean_as_integer);

    // boolean type direct conversion to other types is not possible in Rust.
    // You need to do something like this instead:

    if true {
        boolean_as_integer = -1;
    } else {
        boolean_as_integer = 0; 
    }

    println!("boolean_as_integer {}", boolean_as_integer);

    // Characters

    // In Rust type 'char' represents a single unicode character, 
    // as a 32-bit value. 
    // Only values within specific ranges are permitted.
    // Conversion to integer types is done using the 'as' keyword.
    // You can only convert directly from type u8 however better to 
    // use std::char::from_u32() 

    // Strings

    // Type is used under different contexts here and there
    // A string is represented as sequence of UTF-8 bytes (not chars)

    // There are (to) many type specific methods implemented for 'char' and 'String'
    // like .is_alphabetic(), .to_digit() or .len_UTF(). See documentation.

    // Tuples 
    //   ([value0],{[value1],...,})
    // A comma delimited list of different types.
    // Can be initalized by using pattern matching.
    // No index based access is possible.
    // Extra ',' is permitted and common but not mandatory.
    // You can not dynamically add or remove elements.

    let (first, second,) = (1, "second",);

    // Access via hard coded member location 

    let _tuple = (first, second,);

    println!("_tuple.0 {}", _tuple.0);
    println!("_tuple.1 {}", _tuple.1);

    // () is a empty tuple often used as a return value:
    //   Return<(), std.io.error>

    // As a return value example

    let text = "123 456";
    let (first_number, second_number) = text.split_at(3);

    println!("split_at {}, {}", first_number, second_number);
    println!("split_at {}, {}", (first_number, second_number).0, (first_number, second_number).1);

    // Pointer type Reference 
    //   &[value]  Reference to [value]
    //   *[value]  Value of whatever [value] points to      

    let _string = "This is a string";
    let string_ref = &_string;

    println!("_string {}", _string);
    println!("_string {}", &_string);
    println!("_string {}", string_ref);
    // println!("_string {}", *_string);  // Will mot compile as size of *_string is unknown at compile time
    println!("_string {}", *string_ref);

    // Boxes are used to allocate a value on the heap

    // One example 
    let _t = (12, "eggs");
    let _b = Box::new(_t);

    // Raw pointers are UNSAFE and should only be used 
    // if no other option exists. 
    // Here is a short example to illustrate the main 
    // steps of using raw pointers. 

    // Allocate a string on the heap
    let mut hello = String::from("Hello, World!");

    // Create a raw pointer to the string's buffer
    let raw_ptr: *mut u8 = hello.as_mut_ptr();

    // Print the original string
    println!("Original string: {}", hello);

    // Use unsafe block to modify the string through the raw pointer
    unsafe {
        // Change 'W' to 'R'
        *raw_ptr.add(7) = b'R';
    }

    // Print the modified string
    println!("Modified string: {}", hello);

    // Create another raw pointer and read from it
    let read_ptr: *const u8 = hello.as_ptr();

    // Read and print individual characters using the raw pointer
    println!("Reading characters:");
    for i in 0..hello.len() {
        unsafe {
            let c = *read_ptr.add(i) as char;
            println!("Character at position {}: {}", i, c);
        }
    }
    
    // Array
    // Has a fixed length and can only contain one type
    
    let mut _array: [u8; 4] = [4, 3, 2, 1];

    println!("_array {}", _array.len());
    println!("_array {:?}", _array);

    _array.sort(); // Uses slices but will work any way

    println!("_array {:?}", _array);

    // Vector
    // Has a dynamic length and can only contain one type.
    // Addition and removal of elements is possible.
    // Can live on the heap so can be large.

    // Define using macro vec!()
    let mut v = vec![1, 2, 3, 4, 5];

    println!("v {:?}", v);

    // Iterate and fold example     
    // 2 * 3 = 6
    // 6 * 5 = 30
    // 30 * 7 = 210
    let folded = v.iter().fold(1, |a, b| a * b);

    println!("folded {}", folded);

    // Add elements

    v.push(11);
    v.push(13);

    // Insert a value

    v.insert(1, -1);
 
    println!("v {:?}", v);
   
    // Remove elements
    
    v.remove(0);
    v.remove(2);

    // Pop a value

    v.pop();

    println!("v {:?}", v);

    // Create vector with initial value in each element

    v = vec![-1; 10];

    println!("v {:?}", v);

    // Classic vector creation without vec!()

    let mut vstring = Vec::new();

    vstring.push("yes");
    vstring.push("no");
    vstring.push("possible");

    println!("vstring {:?}", vstring);

    // Using a iterator

    let viterate: Vec<i32> = (0..5).collect();

    println!("viterate {:?}", viterate);
   
    // Define vector with given capacity

    let mut vcapacity = Vec::with_capacity(4);

    println!("vcapacity len {}", vcapacity.len());
    println!("vcapacity capacity {}", vcapacity.capacity());

    println!("vcapacity {:?}", vcapacity);

    vcapacity.push(1);
    vcapacity.push(2);

    println!("vcapacity len {}", vcapacity.len());
    println!("vcapacity capacity {}", vcapacity.capacity());

    println!("vcapacity {:?}", vcapacity);

    // for loop it

    for item in vcapacity{
        println!("item {}", item);
    }

    // Slice
    // Is a reference to a part of an array or vector.
    // Contains a reference to the first item and the 
    // length of the slice.
    // Note: Sometimes it is confusing in Rust when and
    //       if You are using (or need to use) a slice 
    //       and not the root object array or vector.

    let vector_to_slice: Vec<f64> = vec![0.0,  0.707,  1.0,  0.707];
    let array_to_slice:  [f64; 4] =     [0.0, -0.707, -1.0, -0.707];

    // slice_* are actually created by Rust as slices that point to the data
    let slice_vector: &[f64] = &vector_to_slice;
    let slice_array: &[f64] = &array_to_slice;

    println!("slice_vector {:?}", slice_vector);
    println!("slice_array {:?}", slice_array);

    // Example: Passing a slice when You may not notice it 

    print(&vector_to_slice);
    print(&slice_array);

    // Create a specific slice to pass

    // Slice data starts at 0 in &vector_to_slice and has a length of 2
    print(&vector_to_slice[0..2]); 

    // Slice data starts at 2 in &slice_array and has a length of &slice_array minus 2 
    print(&slice_array[2..]);
   
    // Slice a slice of a vector :)
    print(&slice_vector[1..3]);

    // String Types
    // There are two types of strings in Rust. We will not cover 
    // all the String related functions here. We may return to 
    // this later or refer to documentation for details.

    // String Literals

    // Uses escape '\' char 
    let _speech = "\"Ouch!\" said the wall.\n";

    // long line spaces after newline included
    println!("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
              BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB");

    // Spaces not included          
    println!("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\
              BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB");

    // Fed up with escapes use raw 'r""'

    let noescapes = r"C:\MyTemp\MyFile.txt";

    println!("noescapes {}",noescapes);

    // Do not analyze text just use it as is 'r###""###' (number of '#' can be 1...n)

    let ignoretext = r###"\"Hello" 'Today'\n "###;

    println!("ignoretext {}",ignoretext);

    // String defined using bytes (u8 values)

    let method = b"GET";

    // Will not work as not string type
    // println!("method {}",method);   

    // We convert it (one option of many)

    println!("method {}",String::from_utf8_lossy(method));

    // String
    // A String can be in many ways considered a vector
    // Encoding is however variable length Unicode
    // so in memory layout is a complex issue.

    // Note that &str is a string slice and can refer to
    // a string literal or a string. A &str can not itself 
    // be modified.
    // It can be confusing in Rust to know when String or &str 
    // should be used.

    // Creating a String

    // Converts &str into String
    let _error_message = "to many pets".to_string();

    let _string = format!("{}", 22);

    // From vector elements
    let bits = vec!["1", "2", "3"];

    println!("bits concat {}",bits.concat());
    println!("bits join {}",bits.join(", "));

    // Using strings 
    // '==' '!=' '<' '<=' '>' '>=' are supported 
    // There are many utility functions see documentation

    // Other String-Like Types
    //   See std::path:PathBuf and &Path
    //   See OsString and &OsStr
    //   See std::ffi::CString and &CStr

    // User defined types are not covered here
    //   Structs, Enums, Traits, Functions and Closures

} 

fn print_type_of<T>(_: &T) {
    println!("{}", std::any::type_name::<T>());
}