use common::crate_info;

crate_info!();
