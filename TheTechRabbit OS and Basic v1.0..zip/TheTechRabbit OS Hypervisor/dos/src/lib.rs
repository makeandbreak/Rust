use common::crate_info;
use common::library_state_info;

crate_info!();
library_state_info!();

use std::io::{self, Write};

pub fn write(text:&str) -> Result<(), &'static str> {

    if is_library_open() == false {
        return Err("dos library is not open")
    }
 
    if let Err(_e) = writeln!(io::stdout(),"{}", text){
        return Err("writeln!() failed");
    }

    Ok(())
 
 }