
#[macro_export]
macro_rules! crate_info {
    () => {
        pub mod info {
            pub fn name() -> &'static str {
                env!("CARGO_PKG_NAME")
            }
            
            pub fn version() -> &'static str {
                env!("CARGO_PKG_VERSION")
            }
            
            pub fn authors() -> &'static str {
                env!("CARGO_PKG_AUTHORS")
            }
            
            pub fn description() -> &'static str {
                env!("CARGO_PKG_DESCRIPTION")
            }
        }
    };
}

#[macro_export]
macro_rules! library_state_info {
    () => {

        use std::sync::atomic::{AtomicBool};
        use std::sync::atomic::Ordering::{Release, Acquire};

        pub static LIBRARY_IS_OPEN: AtomicBool = AtomicBool::new(false);

        pub fn set_library_is_open() {
            LIBRARY_IS_OPEN.store(true, Release);
        }

        pub fn set_library_is_closed() {
            LIBRARY_IS_OPEN.store(false, Release);
        }

        pub fn is_library_open() -> bool {
            LIBRARY_IS_OPEN.load(Acquire)
        }

    };
}
