use common::crate_info;
use common::library_state_info;

crate_info!();
library_state_info!();

// crate_info test
#[test]
fn pub_mod_info_tests(){
    assert_eq!(info::name().to_string(), "exec");
    assert_eq!(info::version().to_string(), "0.1.0");
    assert_eq!(info::authors().to_string(), "TheTechRabbit <thetechrabbit@thetechrabbit.com>"); 
    assert_eq!(info::description().to_string(), "The exec library");
}

// library_state_info test
#[test]
fn library_state_info_tests(){

    set_library_is_closed();
    
    assert_eq!(is_library_open(), false);
    
    set_library_is_open();

    assert_eq!(is_library_open(), true);

    set_library_is_closed();

    assert_eq!(is_library_open(), false);

}

pub struct Task {pub cli:bool}

// Name: open_library -- gain access to a library
// Synopsis: pub fn open_library(library_name:&str, version:u32) -> Result<&'static str, &'static str>
// Inputs: library_name - the name of the library to open
//	       library_version - the version of the library required
//                           if left empty the latest library version is used
// Result: Ok(version) requested library has been opened and version of the library (crate) is returned  
//         Err(e) requested library coukld not be opened and reason why is returned
pub fn open_library(library_name:&str, library_version:&str) -> Result<&'static str, &'static str> {

    match library_name {
        "asl" => {
                    let current_library_version = asl::info::version();

                    if (library_version != "") && (current_library_version != library_version) {
                        return Err("Requested 'asl' library version is not available");
                    }
                    
                    if asl::is_library_open() == true {
                        return Err("Library 'asl' is already open");
                    }       

                    asl::set_library_is_open();

                    return Ok(current_library_version);
                },
        "diskfont" => {
                        let current_library_version = diskfont::info::version();

                        if (library_version != "") && (current_library_version != library_version) {
                            return Err("Requested 'diskfont' library version is not available");
                        }
                        
                        if diskfont::is_library_open() == true {
                            return Err("Library 'diskfont' is already open");
                        }       

                        diskfont::set_library_is_open();

                        return Ok(current_library_version);
                    },
        "dos" => {
                    let current_library_version = dos::info::version();

                    if (library_version != "") && (current_library_version != library_version) {
                        return Err("Requested 'dos' library version is not available");
                    }
                
                    if dos::is_library_open() == true {
                        return Err("Library 'dos' is already open");
                    }       

                    dos::set_library_is_open();

                    return Ok(current_library_version);
                    },
        "exec" => {
                    let current_library_version = info::version();

                    if (library_version != "") && (current_library_version != library_version) {
                        return Err("Requested 'exec' library version is not available");
                    }
                    
                    if is_library_open() == true {
                        return Err("Library 'exec' is already open");
                    }       

                    set_library_is_open();

                    return Ok(current_library_version);
                },
        "gadtools" => {
                        let current_library_version = gadtools::info::version();

                        if (library_version != "") && (current_library_version != library_version) {
                            return Err("Requested 'gadtools' library version is not available");
                        }
                        
                        if gadtools::is_library_open() == true {
                            return Err("Library 'gadtools' is already open");
                        }       

                        gadtools::set_library_is_open();

                        return Ok(current_library_version);
                    },
        "graphics" => {
                        let current_library_version = graphics::info::version();

                        if (library_version != "") && (current_library_version != library_version) {
                            return Err("Requested 'graphics' library version is not available");
                        }
                        
                        if graphics::is_library_open() == true {
                            return Err("Library 'graphics' is already open");
                        }       

                        graphics::set_library_is_open();
    
                        return Ok(current_library_version);
                    },
        "intuition" => {
                        let current_library_version = intuition::info::version();

                        if (library_version != "") && (current_library_version != library_version) {
                            return Err("Requestd 'intuition' library version is not available");
                        }
                        
                        if intuition::is_library_open() == true {
                            return Err("Library 'intuition' is already open");
                        }       

                        intuition::set_library_is_open();

                        return Ok(current_library_version);
                    },
        "layers" => {
                        let current_library_version = layers::info::version();

                        if (library_version != "") && (current_library_version != library_version) {
                            return Err("Requested 'layers' library version is not available");
                        }
                    
                        if layers::is_library_open() == true {
                            return Err("Library 'layers' is already open");
                        }       

                        layers::set_library_is_open();

                        return Ok(current_library_version);
                    },
        "maths" => {
                    let current_library_version = maths::info::version();

                    if (library_version != "") && (current_library_version != library_version) {
                        return Err("Requested 'maths' library version is not available");
                    }
                    
                    if maths::is_library_open() == true {
                        return Err("Library 'maths' is already open");
                    }       

                    maths::set_library_is_open();

                    return Ok(current_library_version);
                },
        
        _ => return Err("Requested library does not exist"),

    }

}

// Name: close_library -- prevent access to a library
// Synopsis: pub fn close_library(library_name:&str) -> Result<&'static str, &'static str>
// Inputs: library_name - the name of the library to close
// Result: Ok(()) requested library has been closed   
//         Err(e) requested library could not be closed and reason why is returned
pub fn close_library(library_name:&str) -> Result<(), &'static str> {

    match library_name {
        "asl" => {                           
                    if asl::is_library_open() == false {
                        return Err("Library 'asl' is already closed");
                    }       

                    asl::set_library_is_closed();

                    return Ok(());
                },
        "diskfont" => {
                        if diskfont::is_library_open() == false {
                            return Err("Library 'diskfont' is already closed");
                        }       

                        diskfont::set_library_is_closed();

                        return Ok(());
                    },
        "dos" => {
                    if dos::is_library_open() == false {
                        return Err("Library 'dos' is already closed");
                    }       

                    dos::set_library_is_closed();

                    return Ok(());
                    },
        "exec" => {
                    if is_library_open() == false {
                        return Err("Library 'exec' is already closed");
                    }       

                    set_library_is_closed();

                    return Ok(());
                },
        "gadtools" => {
                        if gadtools::is_library_open() == false {
                            return Err("Library 'gadtools' is already closed");
                        }       

                        gadtools::set_library_is_closed();

                        return Ok(());
                    },
        "graphics" => {
                        if graphics::is_library_open() == false {
                            return Err("Library 'graphics' is already closed");
                        }       

                        graphics::set_library_is_closed();
    
                        return Ok(());
                    },
        "intuition" => {
                        if intuition::is_library_open() == false {
                            return Err("Library 'intuition' is already closed");
                        }       

                        intuition::set_library_is_closed();

                        return Ok(());
                    },
        "layers" => {
                        if layers::is_library_open() == false {
                            return Err("Library 'layers' is already closed");
                        }       

                        layers::set_library_is_closed();

                        return Ok(());
                    },
        "maths" => {
                    if maths::is_library_open() == false {
                        return Err("Library 'maths' is already closed");
                    }       

                    maths::set_library_is_closed();

                    return Ok(());
                },
        
        _ => return Err("Requested library does not exist"),
    }
}

// open_library(), close_library() test
#[test]
fn open_close_library_tests(){
 
    assert_eq!(open_library("exec", ""), Ok("0.1.0"));

    assert_eq!(close_library("exec"), Ok(()));

    assert_eq!(open_library("exec", "0.1.0"), Ok("0.1.0"));

    assert_eq!(close_library("exec"), Ok(()));

    assert_eq!(open_library("execCRAP", ""), Err("Requested library does not exist"));

    assert_eq!(open_library("exec", "2.0.0"), Err("Requested 'exec' library version is not available"));

    assert_eq!(open_library("", ""), Err("Requested library does not exist"));
}

pub fn find_task(name:&str) -> Result<Task, &'static str> {

   if is_library_open() == false {
       return Err("exec library is not open")
   }

   if name != "" {
       return Err("We can currently only find oneself")
   }

   // We present CLI for now

   let task = Task {
       cli:true, 
   };

   Ok(task)

}

