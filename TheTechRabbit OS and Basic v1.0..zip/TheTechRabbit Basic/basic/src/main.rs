use exec::open_library;
use exec::close_library;
use exec::find_task;
use dos::write;

// Buffer dans la pile pour debuter
// Buffer into the stack to start
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
struct SpBuffer {
    // sp_message:u16, 
    // sp_auto_lock:u16,
    // sp_auto_name:String,
    // sp_config:String,
    // sp_def_size:u16,
    // sp_command:Vec<u16>,
    // sp_wsegment:u16,
    sp_wbench:bool,
    // sp_command_line:u32    
}

fn main() -> Result<(), Box<dyn std::error::Error>> {

    //  Open exec library
    //  ~~~~~~~~~~~~~~~~~

    match open_library("exec", "") {
        Ok(status) => println!("Open 'exec' library succeeded library version is: {}", status),
        Err(e) => {
                   println!("Open 'exec' library failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  }

    }

    //  Open dos library
    //  ~~~~~~~~~~~~~~~~

    match open_library("dos", "") {
        Ok(status) => println!("Open 'dos' library succeeded library version is: {}", status),
        Err(e) => {
                   println!("Open 'dos' library failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  } 
    }
    
    //  Open intuition library
    //  ~~~~~~~~~~~~~~~~~~~~~~

    match open_library("intuition", "") {
        Ok(status) => println!("Open 'intuition' library succeeded library version is: {}", status),
        Err(e) => {
                   println!("Open 'intuition' library failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  } 
    }

    // CLI ou WORKBENCH?
    // CLI or WORKBENCH?
    // ~~~~~~~~~~~~~~~~~
    
    let mut sp_buffer = SpBuffer {
        // sp_message:0, 
        // sp_auto_lock:0,
        // sp_auto_name:"".to_string(),
        // sp_config:"".to_string(),
        // sp_def_size:0,
        // sp_command:[0, 0].to_vec(),
        // sp_wsegment:0,
        sp_wbench:false,
        // sp_command_line:0  
    };

    // Workbench?
    // ~~~~~~~~~~
    
    let task:exec::Task;

    match find_task("") {
        Ok(task_return) => {
                            println!("Call to find_task() succeeded");
                            task = task_return; 
                           }
        Err(e) => {
                   println!("Call to find_task() failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  }
    }

    sp_buffer.sp_wbench = task.cli;

    match write("Hi there!") {
        Ok(()) => {println!("Call to write() succeeded");}
        Err(e) => {
                   println!("Call to write() failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  }
    }

    //  Close intuition library
    //  ~~~~~~~~~~~~~~~~~~~~~~~

    match close_library("intuition") {
        Ok(()) => {println!("Close 'intuition' library succeeded");}
        Err(e) => {
                   println!("Close 'intuition' library failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  } 
    }

    //  Close dos library
    //  ~~~~~~~~~~~~~~~~

    match close_library("dos") {
        Ok(()) => {println!("Close 'dos' library succeeded");}
        Err(e) => {
                   println!("Close 'dos' library failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  } 
    }

    //  Close exec library
    //  ~~~~~~~~~~~~~~~~~~

    match close_library("exec") {
        Ok(()) => {println!("Close 'exec' library succeeded");}
        Err(e) => {
                   println!("Close 'exec' library failed: {}", e);
                   return Err("Program failed with fatal error!".into());
                  }

    }

    println!("Program ended!");

    Ok(())

}


