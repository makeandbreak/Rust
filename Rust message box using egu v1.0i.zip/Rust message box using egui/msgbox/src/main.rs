
// Import the egui module from the eframe crate
// Exposes egui's types, functions, and other items 
use eframe::egui;

// Define an initial application holder
struct MyApp {

    // Show the message or not
    show_message: bool,
}

// Implement the Default trait in MyApp
impl Default for MyApp {

    // The Default trait requires default()
    fn default() -> Self {

        // The function must return the defualt
        // instance of the type
        Self {
            show_message: false,
        }

    }
}

// Implement the App trait in MyApp
impl eframe::App for MyApp {

    // fn update()  Declares a function named update
    // self    Instance of the type calling the function
    // ctx     The current context
    // _frame  Reference to the curremt Frame ('_' indicates not used in function)
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {

        // default()   Creates a new instance of CentralPanel with default settings
        // show()     Show defined content   
        //   ctx      The current context
        //   |ui| {}  Closure (anonymous function) that takes a ui parameter
        //   ui       Provides methods for adding widgets and controlling the user interface            
        egui::CentralPanel::default().show(ctx, |ui| {

            // Add a header
            ui.heading("Welcome to egui!");
            
            // ui.button() Creates a button widget in the user interface
            // clicked()   Was button clicked in this frame?
            if ui.button("Show Message").clicked() {
                self.show_message = true;
            }

            if self.show_message {

                // Call show_message_box() 
                self.show_message_box(ctx);
            }
        });

    }
}

// Define methods or associated functions for MyApp
impl MyApp {

    // show_message_box()  Define this function
    // self  Will be instance of the type calling the function
    // ctx:  Will be the current context when the function is called
    fn show_message_box(&mut self, ctx: &egui::Context) {

        // Window::new()  Creates a new Window
        // collapsible()  Can window be collapsed
        // resizable()    Can window be resized
        // show()     Show defined content   
        //   ctx      The current context
        //   |ui| {}  Closure (anonymous function) that takes a ui parameter
        //   ui       Provides methods for adding widgets and controlling the user interface             
        egui::Window::new("Message")
            .collapsible(false)
            .resizable(false)
            .show(ctx, |ui| {

                // Add label to window 
                ui.label("This is a message box!");

                // Add some space guidence to window
                ui.add_space(10.0);

                // Has button 
                if ui.button("OK").clicked() {
                    self.show_message = false;
                }
            });

    }

}

fn main() -> eframe::Result<()> {

    // Init run_native() option
    let options = eframe::NativeOptions::default();

    // run_native()   Runs the native GUI application
    // title          Title of application
    // options        Configure various aspects of the application
    // app            A `FnOnce(&CreationContext<'_>)` closure
    //  Box::new()    Create smart pointer that provides heap allocation    
    //       |_cc| Closure that creates a new instance of your application
    //       _cc             Creation context ('_' indicates not used)
    //           Box::new()        Create smart pointer that provides heap allocation 
    //               MyApp::default()  Returns a new instance of application
    eframe::run_native(
        "My egui App",
        options,
        Box::new(|_cc| Ok(Box::new(MyApp::default()))),
    )

}