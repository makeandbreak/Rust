use std::rc::Rc;
use std::cell::Cell;
use std::cell::RefCell;

// Defining GrayscaleMap
//   A rectangle of eight-bit grayscale pixels

struct GrayscaleMap {
    pixels: Vec<u8>,
    size: (usize, usize)
}

// Setup a GrayscaleMap in a function (shorthand)

fn new_map(size: (usize, usize), pixels: Vec<u8>) -> GrayscaleMap {
    assert_eq!(pixels.len(), size.0 * size.1);
    GrayscaleMap { pixels, size }
}

// struct Broom 

struct Broom {

    // All fields are private

    name: String,
    height: u32,
    health: u32,
    position: (f32, f32, f32),
    
    // enum defined outside struct

    intent: BroomIntent
}

// unum BroomIntent

#[derive(Copy, Clone)]    // We want to be able to copy and clone this enum type
#[derive(Debug)]          // We want to be able to include this in debug assert* macro calls 
#[derive(PartialEq)]      // We want to compare this enum type in assert* macro calls
enum BroomIntent { FetchWater, DumpWater }

// Recieve the imput Broom by value, taking ownership
fn chop(b: Broom) -> (Broom, Broom) {

    // Create a new Broom in broom1
    //   '.. b}'    Instructs all fields to be processed that are not explicetly referenced using 'b'  
    //   ...
    //   name: String,     Is not 'Copy' so this gets moved
    //   height: u32,      Referenced by name value from calculation
    //   health: u32,      Is 'Copy' so value copied over as is
    //   position: (f32, f32, f32),   Is 'Copy' so values copied over
    //   intent: BroomIntent   Is defined with derive 'Copy' so value copied over
    //   ...
    let mut broom1 = Broom { height: b.height / 2, .. b};

    // Create a new Broom in broom2
    //   '.. broom1}'    Instructs all fields to be processed that are not explicetly referenced using broom1  
    //   ...
    //   name: String,     Is not 'Copy' so we need to clone it to preserve name in broom1
    //   height: u32,      Is 'Copy' so value copied over as is
    //   health: u32,      Is 'Copy' so value copied over as is
    //   position: (f32, f32, f32),   Is 'Copy' so values copied over
    //   intent: BroomIntent   Is defined with derive 'Copy' so value copied over
    //   ...
    let mut broom2 = Broom { name: broom1.name.clone(), .. broom1 };

    // Give each fragment a distinct name
    broom1.name.push_str(" I");
    broom2.name.push_str(" II");

    // Return tuble containing created brooms
    (broom1, broom2)

}

// fn designates a function
// Command line is not handled as a argument provided by main() 
// This main() function does not return a value
fn main() {

    // println!() is a macro as designated with "!"
    println!("This is the start!");

    // Structure types:
    //   Named-field
    //   Tuple-like
    //   Unit-like

    // Named-Field Structs

    let width = 1024;
    let height = 576;

    // See defining GrayscaleMap above

    let _image = new_map((width, height), vec![0; width*height]);
 
    // Using GrayscaleMap

    let image = GrayscaleMap {
        pixels: vec![0; width*height],
        size: (width, height)
    };

    // Accessing GrayscaleMap fields using '.'
 
    assert_eq!(image.size, (1024, 576));
    assert_eq!(image.pixels.len(), 1024 * 576);

    // A fully public struct

    pub struct _GrayscaleMapFullPublic {
        pub pixels: Vec<u8>,
        pub size: (usize, usize)
    }

    // Members are private

    pub struct _GrayscaleMapPrivateMembers {
        pixels: Vec<u8>,
        size: (usize, usize)
    }

    // Playing with brooms

    let hokey = Broom {
        name: "Hokey".to_string(),
        height: 60,
        health: 100,
        position: (100.0, 200.0, 0.0),
        intent: BroomIntent::FetchWater
    };

    let (hokey1, mut hokey2) = chop(hokey);

    assert_eq!(hokey1.name, "Hokey I");
    assert_eq!(hokey1.health, 100);
    assert_eq!(hokey1.position, (100.0, 200.0, 0.0));
    assert_eq!(hokey1.intent, BroomIntent::FetchWater);

    // Change value to demonstrate enum value DumpWater also works

    hokey2.intent = BroomIntent::DumpWater;

    assert_eq!(hokey2.name, "Hokey II");
    assert_eq!(hokey2.health, 100);
    assert_eq!(hokey2.position, (100.0, 200.0, 0.0));
    assert_eq!(hokey2.intent, BroomIntent::DumpWater);
   
    // Tuple-Like Structs

    struct Bounds(usize, usize);

    let image_bounds = Bounds(1024, 768);

    assert_eq!(image_bounds.0 * image_bounds.1, 786432);

    // Fields as public 

    struct _BoundsPublic(pub usize, pub usize);

    // Nice trick - Name wrapper for standard types

    struct MyData(Vec<u32>);

    // Defining struct methods with impl 
    
    impl MyData {
        
        // Method to get an element by index
        fn get(&self, index: usize) -> Option<&u32> {
            self.0.get(index)
        }
        
        // Method to set an element by index
        fn set(&mut self, index: usize, value: u32) {
            if index < self.0.len() {
                self.0[index] = value;
            }
        }

        // Method to add an element
        fn push(&mut self, value: u32) {
            self.0.push(value);
        }

    }
     
    let mut my_data = MyData(vec![0; 10]);

    // Set a specific entry

    my_data.set(2, 42);
 
    // Get the value

    if let Some(value) = my_data.get(2) {
        println!("Value at index 2: {}", value);
    }
    
    // Push in values

    my_data.push(99);
    
    if let Some(value) = my_data.get(10) {
        println!("Value at new index 10: {}", value);
    }

    // Unit-Like Structs
    //   A type of which there is only a single value

    struct Onesuch;

    let _o = Onesuch;

    // Range { } is the same as unit-like struct RangeFull

    // Struct Layout in memory

    // All fields will be in same memory block but order can not be guarenteed

    // Using the '#[repr(C)]' attribute will force compatibility with C and C++

    // Defining Methods with impl (more details)

    // A first-in, first-out queue of characters

    pub struct Queue {
        older: Vec<char>,     // older elements, oldest last
        younger: Vec<char>    // younger elements, youngest last
    }

    impl Queue {

        // Push a character onto the back of the queue

        // Both fn definitions produce same code
        // pub fn push(&mut self, c:char) { 
        pub fn push(self: &mut Queue, c:char) {
            self.younger.push(c);
        }

        // Pop a character off the front of the queue, Return 'Some(c)' if there
        // was a character to pop, or 'None' if the queue was empty

        // Both fn definitions produce same code
        // pub fn pop(&mut self) -> Option<char> {
        pub fn pop(self: &mut Queue) -> Option<char> {

            if self.older.is_empty() {
                if self.younger.is_empty() {
                    return None;
                }

                // Bring the elements in younger over to older, and put them in
                // the promised order
                use std::mem::swap;
                swap(&mut self.older, &mut self.younger);
                self.older.reverse();
            }

            // Now older is quaranteed to have something, Vec's pop method
            // already returns an Option, so we're set.
            self.older.pop()
        }

        // self will not be modified, use a reference instead
        pub fn is_empty(&self) -> bool {
            self.older.is_empty() && self.younger.is_empty()
        }

        // Taking ownership of self
        pub fn split(self) -> (Vec<char>, Vec<char>) {
            (self.older, self.younger)
        }

        // Static method
          
        // This will also work
        // pub fn new_object() -> Queue {
        pub fn new() -> Queue {
            Queue { older: Vec::new(), younger: Vec::new() }
        }

    }

    // Using Queue

    let mut q = Queue { older: Vec::new(), younger: Vec::new() };

    q.push('0');
    q.push('1');
    
    assert_eq!(q.pop(), Some('0'));

    q.push('=');
    // Is same as this: 
    //  (&mut q).push('=');

    assert_eq!(q.pop(), Some('1'));
    assert_eq!(q.pop(), Some('='));
    assert_eq!(q.pop(), None);

    // Using .is_empty()

    assert!(q.is_empty());
    q.push('0');
    assert!(!q.is_empty());

    // Using .split()

    q = Queue { older: Vec::new(), younger: Vec::new() };

    q.push('P');
    q.push('D');
    assert_eq!(q.pop(), Some('P'));
    q.push('X');

    let (older, younger) = q.split();

    // q is now uninitialized

    assert_eq!(older, vec!['D']);
    assert_eq!(younger, vec!['X']);

    let _q = Queue::new();
    // This will also work
    // q = Queue::new_object();
    
    // Add a function to a basic type i32

    // Define a trait called Arithmetic
    trait Arithmetic {
        fn square(self) -> i32;
    }

    // Implement the trait for i32
    impl Arithmetic for i32 {
        fn square(self) -> i32 {
            self * self
        }
    }

    let number: i32 = 5;

    println!("The square of {} is {}", number, number.square());

    // Generic Structs

    // Queue that can hold items of any type

    pub struct QueueGeneric<T> {
        older: Vec<T>,
        younger: Vec<T>
    }

    #[allow(dead_code)]
    impl<T> QueueGeneric<T> {

        // Push a item of type T onto the back of the queue
        pub fn push(&mut self, item:T) { 
            self.younger.push(item);
        }

        // Pop a character off the front of the queue, Return 'Some(c)' if there
        // was a character to pop, or 'None' if the queue was empty
        pub fn pop(&mut self) -> Option<T> {
        
            if self.older.is_empty() {
                if self.younger.is_empty() {
                    return None;
                }

                // Bring the elements in younger over to older, and put them in
                // the promised order
                use std::mem::swap;
                swap(&mut self.older, &mut self.younger);
                self.older.reverse();
            }

            // Now older is quaranteed to have something, Vec's pop method
            // already returns an Option, so we're set.
            self.older.pop()
        }

        // self will not be modified, use a reference instead
        pub fn is_empty(&self) -> bool {
            self.older.is_empty() && self.younger.is_empty()
        }

        // Taking ownership of self
        pub fn split(self) -> (Vec<T>, Vec<T>) {
            (self.older, self.younger)
        }

        // Static method
        // Note usega of 'Self'
        pub fn new() -> Self {
            QueueGeneric { older: Vec::new(), younger: Vec::new() }
        }

    }

    // Using QueueGeneric<T>
    
    // Define explicit type in declaration 

    let mut _q = QueueGeneric::<char>::new();

    // ...or we do not bother

    let mut q = QueueGeneric::new();
    let mut r = QueueGeneric::new();

    // Let Rust decide types

    q.push("CAD");  // Apparently a QueueGeneric<&'static str>
    r.push(0.74);  // Apparently a QueueGeneric<f64>

    q.push("BTC"); // Bitcoins per USD, 2017-S
    r.push(2737.7); // Rust fails to detect irrasioanl exubarence

    // Struct with lifetime parameters

    // Accept any lifetime ('elt") when struct declared for use
    
    struct Extrema<'elt> {
        greatest: &'elt i32,
        least: &'elt i32
    }

    // If no specific lifetime intended we can use
    //   fn find_extrema(slice: &[i32]) -> Extrema {
    // In this case we specifically define lifetime 's
    fn find_extrema<'s>(slice: &'s [i32]) -> Extrema<'s> {
        let mut greatest = &slice[0];
        let mut least = &slice[0];

        for i in 1..slice.len() {
            if slice[i] < *least     { least = &slice[i]; }
            if slice[i] > *greatest  { greatest = &slice[i]; }
        }
        Extrema { greatest, least }
    }

    // Using Extrema<'elt>

    let a = [0, -3, 0, 15, 48];
    let e = find_extrema(&a);
    assert_eq!(*e.least, -3);
    assert_eq!(*e.greatest, 48);

    // Deriving common traits for struct types

    // Simple definition but can be useless in the long run
    // You can not easily copy, clone, debug or compare this
    
    struct _PointSimple {
        x: f64,
        y: f64
    }

    // Apply the traits

    #[derive(Copy, Clone, Debug, PartialEq)]
    struct _Point {
        x: f64,
        y: f64
    }

    // Now You can easily copy, clone, debug or compare the above 

    // Interior mutability using Cell<T>
    //   Cell<T> is a construct in Rust's standard library that provides interior 
    //   mutability, allowing you to modify data even when accessed through an 
    //   immutable reference. This is fundamentally in contrast to Rust’s typical 
    //   handling of mutability and borrowing rules, where mutable access requires 
    //   mutable references.

    pub struct SpiderRobot {
        battery_level: Cell<i32>, // Internally mutable field
    }
    
    impl SpiderRobot {
        fn new(initial_battery: i32) -> SpiderRobot {
            SpiderRobot {
                battery_level: Cell::new(initial_battery),
            }
        }

        fn recharge(&self) {
            // This method modifies battery_level through interior mutability
            let new_level = self.battery_level.get() + 10;
            self.battery_level.set(new_level);
        }

        fn get_battery_level(&self) -> i32 {
            self.battery_level.get()
        }
    }

    pub struct SpiderSenses {
        robot: Rc<SpiderRobot>    // Smart pointer to SpiderRobot
    }
    
    impl SpiderSenses {
        fn new(robot: Rc<SpiderRobot>) -> SpiderSenses {
            SpiderSenses { robot }
        }

        fn boost_battery(&self) {
            // Call recharge on the SpiderRobot instance
            self.robot.recharge();
        }

        fn view_battery(&self) -> i32 {
            // Access the current battery level
            self.robot.get_battery_level()
        }
    }
    
    let robot = Rc::new(SpiderRobot::new(50));
    let senses = SpiderSenses::new(Rc::clone(&robot));
    
    // View battery level
    println!("Initial battery level: {}", senses.view_battery());

    // Boost battery using SpiderSenses
    senses.boost_battery();
    println!("Battery level after boost: {}", senses.view_battery());

    // Recharge directly via SpiderRobot
    robot.recharge();
    println!("Battery level after direct recharge: {}", senses.view_battery());

    // Interior mutability using RefCell<T>
    //   RefCell<T> is a type in Rust's standard library that provides interior mutability, 
    //   allowing you to mutate data even when there are only immutable references to the 
    //   RefCell. This capability is useful in scenarios where Rust's usual borrowing 
    //   rules—requiring mutable access for mutation—are too restrictive or impractical.

    pub struct SpiderRobotAdvanced {
        battery_level: RefCell<i32>, // Allows mutable borrows of the inner value
    }

    impl SpiderRobotAdvanced {

        fn new(initial_battery: i32) -> SpiderRobotAdvanced {
            SpiderRobotAdvanced {
                battery_level: RefCell::new(initial_battery),
            }
        }

        fn recharge(&self) {
            // Borrow mutably to modify the battery level
            *self.battery_level.borrow_mut() += 10;
        }

        fn get_battery_level(&self) -> i32 {
            // Read current battery level
            *self.battery_level.borrow()
        }

    }

    pub struct SpiderSensesAdvanced {
        robot: Rc<SpiderRobotAdvanced>    // Smart pointer to SpiderRobot
    }

    impl SpiderSensesAdvanced {

        fn new(robot: Rc<SpiderRobotAdvanced>) -> SpiderSensesAdvanced {
            SpiderSensesAdvanced { robot }
        }

        fn boost_battery(&self) {
            // Use recharge method to boost battery
            self.robot.recharge();
        }

        fn view_battery(&self) -> i32 {
            // Access the current battery level
            self.robot.get_battery_level()
        }
    }

    let robot = Rc::new(SpiderRobotAdvanced::new(50));
    let senses = SpiderSensesAdvanced::new(Rc::clone(&robot));
    
    // View battery level
    println!("Initial battery level: {}", senses.view_battery());

    // Boost battery using SpiderSensesAdvanced
    senses.boost_battery();
    println!("Battery level after boost: {}", senses.view_battery());

    // Recharge directly via SpiderRobotAdvanced
    robot.recharge();
    println!("Battery level after direct recharge: {}", senses.view_battery());

    // You can cause a panic in some use cases

    let ref_cell: RefCell<String> = RefCell::new("Hello".to_string());

    let r = ref_cell.borrow();   // ok, returns a Ref<String>
    let count = r.len();         // ok, returns "Hello".len()
    assert_eq!(count, 5);

    // Panic: Already borrowed
    //  let mut w = ref_cell.borrow_mut();    
    //  w.push_str(" world");

    println!("This is the end!");
}

