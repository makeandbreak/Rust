use fltk::{app, button::Button, prelude::*, window::Window};

// Disable console window and console output on startup
//  #![windows_subsystem = "windows"]

fn main() {

    // Initialize the app
    // App        Struct represents the main application in FLTK
    // default()  Create an instance of the type with default values
    
    let app = app::App::default();

    // Create a window
    //   Window::new(x, y, width, height, title)
    //   x, y           Window location top-left corner on the screen
    //   width, height  Window width and height
    //   title          Title of window
    let mut wind = Window::new(100, 100, 400, 300, "Message Box Example");

    // Note:
    //   When you create a widget (like a button) after creating a window 
    //   but before calling wind.end(), FLTK automatically associates that 
    //   widget with the most recently created (or activated) window.
    //   if you're managing multiple windows or complex nested layouts
    //   the use of this concept can cause confusion. 

    // Create a button
    //   Button::new(x, y, width, height, label, shortcut)
    //   x, y           Button location top-left corner relative to its parent widget 
    //   width, height  Button width and height
    //   label          Label of button
    //   shortcut       Leyboard shortcut (optional)
    let mut but = Button::new(160, 210, 80, 40, "Click Me!");

    // Make the window resizable
    
    wind.make_resizable(true);

    // Indicate adding child widgets is complete

    wind.end();

    // Show window 

    wind.show();

    // Set the button's callback
    
    but.set_callback(|_| {
    
        // Create and show the message box
    
        fltk::dialog::message_default("Hello from FLTK-rs!");
    });

    // Run the app
    //   app.run()     Start the main event loop 
    //   .unwrap()     Method called on the Result returned by app.run()
    //                 In case of Err(FltkError) the program will panic and exit
    app.run().unwrap();

}

fn _main() {

    // Just need a message box

    fltk::dialog::message_default("Hello from FLTK-rs!");
}
