use std::collections::HashMap;

type Table = HashMap<String, Vec<String>>;

fn _show(table: Table) {
    for (dog_breed, names) in table {
        println!("dogs of breed {}:", dog_breed);
        for name in names {
            println!("   {}", name);
        }
    }
}

fn show_ref(table: &Table) {
    for (dog_breed, names) in table {
        println!("dogs of breed {}:", dog_breed);
        for name in names {
            println!("   {}", name);
        }
    }
}

fn sort_names(table: &mut Table){
    for (_dog_breed, names) in table {
        names.sort();
    }
}

fn main() {

    println!("Hello, references and scope!");

    let mut table = Table::new();

    table.insert("Retriever".to_string(),
                 vec!["Ronny".to_string(),
                      "Jive".to_string()]
    );

    table.insert("Labradore".to_string(),
                 vec!["Charles".to_string(),
                      "Winston".to_string()]
    );

    table.insert("Poodle".to_string(),
                 vec!["Edward".to_string(),
                      "Sammy".to_string()]
    );
    
    // This moves table 
    //_show(table);

    // Until here all is OK however as table value borrowed after move
    // amd it no longer exists this will fail.
    //assert_eq!(table["Labradore"][0], "Ronny");

    // So we need to use a reference instead

    // Reference types in Rust
    //   Shared reference    Read only reference to referent but
    //                       can be as many as You like.
    //                       (&T) as in "ref T" and are Copy
    //   Mutable reference   Read and write access to referent but 
    //                       only one reference can be active at one time. 
    //                       (&mut T) as oin "ref mute T" and are not Copy
    //
    // References most never outlive their referents (checked compile time)

    // Se we try again (by reference)

    show_ref(&table);

    // Now table still exists

    assert_eq!(table[&"Labradore".to_string()][0], "Charles");

    // Sort using a mutable reference (by value)

    sort_names(&mut table);

    // Dereferncing using '*' to access value

    let x = 10;
    let r = &x;
    assert!(*r == 10);

    let mut y = 32;
    let m = &mut y;
    *m += 32;
    assert!(*m == 64);

    // The '.' operator implicitely dereferences its 
    // left operand, if needed
 
    struct Part { name:&'static str, _in_stock: bool }

    let part = Part { name: "Bolt", _in_stock: true };
    let part_ref = &part;

    assert_eq!(part.name, "Bolt");  

    // Equivalent but without '.'

    assert_eq!((*part_ref).name, "Bolt");

    // The '.' operator can also implicitely borrow its 
    // left operand, if needed for a method call

    let mut v = vec![73, 68];
    v.sort();

    // Equivalent but without '.' doing the work for us

    (&mut v).sort();

    // Note: println!() macro expands to code that uses '.'

    // Assigning references

    let x2 = 10;
    let y2 = 20;

    let mut _r = &x2;

    // We re-assign reference

    _r = &y2;

    assert!(*_r == 10 || *_r == 20);

    // References to references

    struct Point { _x: i32, y: i32 }
    let point = Point { _x: 1000, y: 729 };
    let k: &Point = &point;
    let kk: &&Point = &k;
    let kkk: &&&Point = &kk;
    
    // '.' will dereference until value is 'found'

    assert_eq!(kkk.y, 729);
    
    // Comparing references

    let x3 = 10;
    let y3 = 10;

    let rx = &x3;
    let ry = &y3;

    let rrx = &rx;
    let rry = &ry;

    // Walks the links until x and y values are found 
    // x and y need to be of same type

    assert!(rrx <= rry);
    assert!(rrx == rry);

    // Do two refernces point to same memory location?

    assert!(rx == ry);
    assert!(std::ptr::eq(rx, ry));

    // Note: Rust references can not be and never are null

    // Borrowing references to arbitraru expressions
    // '&' will create hidden anonymous variables that have 
    // different lifetimes

    fn add(a:i32, b:i32) -> i32 {
        a+b
    }

    let r = &add(2, 2);

    // Arithmetic operators can 'see' through one level of references

    assert_eq!(r + &10, 20);

    // References to slices and trait objects
    // Are fat pointers but bahave in the same way
    // More on this in a later section

    // Reference safety

    // Lifetime scope example - Borrowing a local variable 

    {
        let r;
        {
            let x = 1;
            r = &x;
            // Line will work here
            assert_eq!(*r, 1);
        }

        // bad: reads memory 'x' used to occupy
        // lifetime of reference '&x' (now in r) can not exceed 
        // that of the referent 'x'
        //assert_eq!(*r, 1);
        
    }

    // Recieving references as parameters








}
