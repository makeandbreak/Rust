
use std::collections::HashMap;
use std::hash::Hash;
use std::cmp::Reverse;

// Force check for Debug trait:
//   pub fn top_10_most_common<T: Debug + Hash + Eq + Clone + Ord>(items: Vec<T>) -> Vec<(T, usize)> {
//
// Move type definition to seperate line:
//   pub fn top_10_most_common<T>(items: Vec<T>) -> Vec<(T, usize)> 
//        where T: Hash + Eq + Clone + Ord       
//   {
//
pub fn top_10_most_common<T: Hash + Eq + Clone + Ord>(items: Vec<T>) -> Vec<(T, usize)> {
 
    // Count occurrences of each item
 
    let mut counts = HashMap::new();
 
    for item in items {
        *counts.entry(item).or_insert(0) += 1;
    }

    // Collect into a vector and sort by count (descending) then by value (ascending)
 
    let mut count_vec: Vec<_> = counts.into_iter().collect();
 
    count_vec.sort_by(|(a_val, a_count), (b_val, b_count)| {
        b_count.cmp(a_count).then(a_val.cmp(b_val))
    });

    // Take top 10 and return
 
    count_vec.into_iter().take(10).collect()
}

// Alternative version using a max-heap (often more efficient for large collections)
pub fn _top_10_most_common_heap_alt<T: Hash + Eq + Clone + Ord>(items: Vec<T>) -> Vec<(T, usize)> {

    let mut counts = HashMap::new();

    for item in items {
        *counts.entry(item).or_insert(0) += 1;
    }

    // Use a binary heap to efficiently get top counts

    use std::collections::BinaryHeap;

    let heap: BinaryHeap<_> = counts.into_iter().map(|(val, count)| (count, Reverse(val))).collect();
    
    heap.into_sorted_vec()
        .into_iter()
        .rev()
        .take(10)
        .map(|(count, Reverse(val))| (val, count))
        .collect()
}

fn find_nearest<'a, T>(target: &T, candidates: &[&'a T]) -> Option<&'a T>
where
    T: PartialOrd + PartialEq,
{
    let mut nearest: Option<&'a T> = None;
    let mut min_diff: Option<&T> = None;

    for &candidate in candidates {
        if target == candidate {
            return Some(candidate);
        }

        let current_diff = if candidate > target {
            candidate
        } else {
            target
        };

        if min_diff.is_none() || current_diff < min_diff.unwrap() {
            min_diff = Some(current_diff);
            nearest = Some(candidate);
        }
    }

    nearest
}

// Defining and implementing traits 

trait Speak {
    fn speak(&self);
}

struct Dog;
struct Cat;
struct Human;

impl Speak for Dog {
    fn speak(&self) { println!("Woof!"); }
}

impl Speak for Cat {
    fn speak(&self) { println!("Meow!"); }
}

impl Speak for Human {
    fn speak(&self) { println!("Hello!"); }
}

// Using self as a type

trait Animal {
    fn new(name: String) -> Self;
    fn make_sound(&self) -> String;
    fn describe(&self) -> String {
        format!("I am a {} named {}", self.species(), self.name())
    }
    fn name(&self) -> &str;
    fn species(&self) -> &str;
}

 struct SmallDog {
    name: String,
}

impl Animal for SmallDog {
    fn new(name: String) -> Self {
        SmallDog { name }
    }

    fn make_sound(&self) -> String {
        "Woof!".to_string()
    }

    fn name(&self) -> &str {
        &self.name
    }

    fn species(&self) -> &str {
        "dog"
    }
}

struct LargeCat {
    name: String,
}

impl Animal for LargeCat {
    fn new(name: String) -> Self {
        LargeCat { name }
    }

    fn make_sound(&self) -> String {
        "Meow!".to_string()
    }

    fn name(&self) -> &str {
        &self.name
    }

    fn species(&self) -> &str {
        "cat"
    }
}

// A trait that uses the Self type is incompatible with trait objects

trait CloneAnimal {
    fn clone(&self) -> Self;
}

struct LargeDog {
    name: String,
}

impl CloneAnimal for LargeDog {
    fn clone(&self) -> Self {
        LargeDog { name: self.name.clone() }
    }
}

struct SmallCat {
    name: String,
}

impl CloneAnimal for SmallCat {
    fn clone(&self) -> Self {
        SmallCat { name: self.name.clone() }
    }
}

// Subtrait

// Define a supertrait

trait AnimalTrait {
    fn name(&self) -> &str;
    fn make_sound(&self);
}

// Define a subtrait that requires Animal as a supertrait

trait Pet: AnimalTrait {
    fn owner(&self) -> &str;
    fn greet(&self) {
        println!("{} says hello to {}!", self.name(), self.owner());
        self.make_sound();
    }
}

// Implement both traits for a struct

struct DogStruct {
    name: String,
    owner: String,
}

impl AnimalTrait for DogStruct {
    fn name(&self) -> &str {
        &self.name
    }
    
    fn make_sound(&self) {
        println!("Woof!");
    }
}

impl Pet for DogStruct {
    fn owner(&self) -> &str {
        &self.owner
    }
}

// Function that accepts any type implementing Pet

fn pet_interaction<T: Pet>(pet: &T) {
    println!("Special interaction with {}:", pet.name());
    pet.greet();
}

// Static methods

// Define a trait with a static method

trait Factory {

    // Static method that creates a new instance (no self parameter)

    fn new(name: &str) -> Self;
    
    // Another static method with a default implementation

    fn default() -> Self where Self: Sized {
        Self::new("default")
    }
}

// Implement the trait for a struct

struct Product {
    name: String,
}

impl Factory for Product {
    fn new(name: &str) -> Self {
        Product {
            name: name.to_string(),
        }
    }
}

// where Self: Sized

trait Example {
    // This method is only available when Self is sized
    fn sized_method(&self) where Self: Sized {
        println!("This method requires Self to be sized");
    }
    
    // This method is available for all implementors
    fn unsized_method(&self) {
        println!("This method works for both sized and unsized types");
    }
}

struct MyStruct;

impl Example for MyStruct {}

// Fully qualified method calls

// When two methods have the same name

trait Pilot {
    fn fly(&self);
}

trait Wizard {
    fn fly(&self);
}

struct HumanStruct;

impl Pilot for HumanStruct {
    fn fly(&self) {
        println!("This is your captain speaking.");
    }
}

impl Wizard for HumanStruct {
    fn fly(&self) {
        println!("Up!");
    }
}

impl HumanStruct {
    fn fly(&self) {
        println!("*waving arms furiously*");
    }
}

// Example with associated functions

trait MyAnimal {
    fn name() -> String {
        String::from("animal")
    }
}

struct MyDog;

impl MyAnimal for MyDog {}

impl MyDog {
    fn name() -> String {
        String::from("dog")
    }
}

// When the type of the self argument can not be inferred

use std::any::Any;

#[allow(dead_code)]
trait Engine: Any {
    fn start(&self) -> String;
    
    // Helper method for downcasting

    fn as_any(&self) -> &dyn Any;
}

trait Vehicle: Any {
    fn start(&self) -> String;
    
    // Helper method for downcasting
    
    fn as_any(&self) -> &dyn Any;
}

#[derive(Debug)]
struct Car;

impl Engine for Car {
    fn start(&self) -> String {
        "Engine roaring to life!".to_string()
    }
    
    fn as_any(&self) -> &dyn Any {
        self
    }
}

impl Vehicle for Car {
    fn start(&self) -> String {
        "Vehicle starting up...".to_string()
    }
    
    fn as_any(&self) -> &dyn Any {
        self
    }
}

impl Car {
    fn start(&self) -> String {
        "Car starting".to_string()
    }
}

// Generic function examples

fn _print_engine_start<T: Engine>(item: &T) {
    println!("Generic Engine call: {}", <T as Engine>::start(item));
}

fn _print_vehicle_start<T: Vehicle>(item: &T) {
    println!("Generic Vehicle call: {}", <T as Vehicle>::start(item));
}

// When using the function itself as a function value

trait Formatter {
    fn format(&self, input: &str) -> String;
    
    // Static function must have Self: Sized bound to be dyn-compatible

    fn default_format(input: &str) -> String 
    where
        Self: Sized,
    {
        input.to_uppercase()
    }
}

// Implement for concrete types

struct UppercaseFormatter;
struct LowercaseFormatter;

impl Formatter for UppercaseFormatter {
    fn format(&self, input: &str) -> String {
        input.to_uppercase()
    }
}

impl Formatter for LowercaseFormatter {
    fn format(&self, input: &str) -> String {
        input.to_lowercase()
    }
    
    // Override default implementation

    fn default_format(input: &str) -> String {
        input.to_lowercase()
    }
}

// Helper function demonstrating passing formatters

fn _apply_format(formatter: &dyn Formatter, input: &str) -> String {
    formatter.format(input)
}

// When calling trait methods in macros

trait MyFormatter {
    fn format(&self, input: &str) -> String;
    
    fn default_format(input: &str) -> String 
    where
        Self: Sized,
    {
        input.to_uppercase()
    }
}

struct MyUppercaseFormatter;
struct MyLowercaseFormatter;

impl MyFormatter for MyUppercaseFormatter {
    fn format(&self, input: &str) -> String {
        input.to_uppercase()
    }
}

impl MyFormatter for MyLowercaseFormatter {
    fn format(&self, input: &str) -> String {
        input.to_lowercase()
    }
    
    fn default_format(input: &str) -> String {
        input.to_lowercase()
    }
}

// Macro that demonstrates fully qualified calls

macro_rules! format_with {

    ($formatter:expr, $input:expr) => {

        // Fully qualified method call
        
        <_ as MyFormatter>::format($formatter, $input)
    };
    
    ($trait:ty, $input:expr) => {
        
        // Fully qualified static method call

        <$trait as MyFormatter>::default_format($input)
    };
    
    ($input:expr) => {

        // Default implementation

        <MyUppercaseFormatter as MyFormatter>::default_format($input)
    };
}

// Macro that generates wrapper functions

macro_rules! create_formatter_fn {
    ($name:ident, $formatter:ty) => {

        fn $name(input: &str) -> String {

            // Fully qualified call in generated function

            <$formatter as MyFormatter>::default_format(input)
        }
    };
}

// Generate concrete functions using the macro

create_formatter_fn!(_format_upper, MyUppercaseFormatter);
create_formatter_fn!(_format_lower, MyLowercaseFormatter);

// When calling static methods

trait MathOperations {
    
    // Static method with default implementation

    fn add(a: i32, b: i32) -> i32 {
        a + b
    }

    // Static method without default implementation

    fn multiply(a: i32, b: i32) -> i32;
}

struct Calculator;

impl MathOperations for Calculator {
    
    // Override the default add implementation
    
    fn add(a: i32, b: i32) -> i32 {
        a + b + 1  // Special behavior for Calculator
    }

    // Required implementation
    
    fn multiply(a: i32, b: i32) -> i32 {
        a * b
    }
}

struct ScientificCalculator;

impl MathOperations for ScientificCalculator {
    // Use default add implementation
    
    // Specialized multiply implementation
    
    fn multiply(a: i32, b: i32) -> i32 {
        (a as f64 * b as f64).round() as i32  // Fancy scientific version
    }
}

// Generic function using fully qualified syntax

fn print_operation<T: MathOperations>(a: i32, b: i32) {
    println!(
        "Generic operation - Add: {}, Multiply: {}",
        <T as MathOperations>::add(a, b),
        <T as MathOperations>::multiply(a, b)
    );
}

// Function comparing different implementations

fn compare_implementations(a: i32, b: i32) {
    println!("\nImplementation comparison:");
    println!("Calculator:          Add {} + {} = {}", a, b, <Calculator as MathOperations>::add(a, b));
    println!("Scientific:          Add {} + {} = {}", a, b, <ScientificCalculator as MathOperations>::add(a, b));
    println!("Calculator:     Multiply {} * {} = {}", a, b, <Calculator as MathOperations>::multiply(a, b));
    println!("Scientific:     Multiply {} * {} = {}", a, b, <ScientificCalculator as MathOperations>::multiply(a, b));
}

// Associated types (or how iterators work)

use std::fmt;

// A simple struct that will be our iterator

struct Countdown {
    count: u32,
}

// Implement Iterator for Countdown

impl Iterator for Countdown {
    type Item = u32;  // Associated type declaration

    fn next(&mut self) -> Option<Self::Item> {
        if self.count == 0 {
            None
        } else {
            let current = self.count;
            self.count -= 1;
            Some(current)
        }
    }
}

// Implement Debug for Countdown to print iteration state

impl fmt::Debug for Countdown {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Countdown {{ remaining: {} }}", self.count)
    }
}

// Generic traits (or how operator overloading works)

use std::ops::Mul;

// A simple 2D vector struct

#[derive(Debug, PartialEq)]
struct Vector2D {
    x: f64,
    y: f64,
}

// Implement scalar multiplication (Vector2D * f64)

impl Mul<f64> for Vector2D {
    type Output = Vector2D;

    fn mul(self, scalar: f64) -> Vector2D {
        Vector2D {
            x: self.x * scalar,
            y: self.y * scalar,
        }
    }
}

// Implement vector dot product (Vector2D * Vector2D)

impl Mul<Vector2D> for Vector2D {
    type Output = f64;

    fn mul(self, other: Vector2D) -> f64 {
        self.x * other.x + self.y * other.y
    }
}

// A custom type for units of measurement

#[derive(Debug, PartialEq)]
struct Meter(f64);

// Implement multiplication between Meter types

impl Mul for Meter {
    type Output = MeterSquared;

    fn mul(self, other: Meter) -> MeterSquared {
        MeterSquared(self.0 * other.0)
    }
}

// Result type for Meter * Meter

#[derive(Debug, PartialEq)]
struct MeterSquared(f64);

// Buddy traits (or how rand:random() works)
//    The specific use of "Buddy traits" has been depreciated
//    but code may still exist that uses it. Here we provide
//    the latest style of implementing the same functionality.

use rand::{
    RngCore,
    Rng,
    SeedableRng,
    rngs::StdRng,
};

use rand_distr::StandardNormal;

// 1. Custom RNG implementation

#[derive(Debug, Clone)]
struct SimpleRng {
    state: u64,
}

impl SimpleRng {
    fn new(seed: u64) -> Self {
        SimpleRng { state: seed }
    }
}

impl RngCore for SimpleRng {

    fn next_u32(&mut self) -> u32 {
        self.state = self.state.wrapping_mul(6364136223846793005).wrapping_add(1);
        (self.state >> 32) as u32
    }

    fn next_u64(&mut self) -> u64 {
        self.state = self.state.wrapping_mul(6364136223846793005).wrapping_add(1);
        self.state
    }

    fn fill_bytes(&mut self, dest: &mut [u8]) {

        // Efficient byte filling using next_u64
        
        let mut left = dest;
        
        while left.len() >= 8 {
            let (l, r) = {left}.split_at_mut(8);
            left = r;
            let chunk: [u8; 8] = self.next_u64().to_le_bytes();
            l.copy_from_slice(&chunk);
        }

        let n = left.len();
        
        if n > 0 {
            let chunk: [u8; 8] = self.next_u64().to_le_bytes();
            left.copy_from_slice(&chunk[..n]);
        }
    }
}

// 2. Custom type we want to generate randomly

#[derive(Debug, PartialEq)]
struct Point {
    x: i32,
    y: i32,
}

// Implement custom random generation for Point

impl Point {

    // Generate a random point using any RNG

    pub fn random<R: Rng>(rng: &mut R) -> Self {
        Point {
            x: rng.random_range(-100..=100),
            y: rng.random_range(-100..=100),
        }
    }
}

// Reverse-engineering bounds

fn dot(v1: &[i64], v2: &[i64]) -> i64 {
    let mut total = 0;
    for i in 0 .. v1.len() {
        total = total + v1[i] + v2[i];
    } 
    total
}

// We want to also calculate using floating-point

/*
fn dot_gen<N>(v1: &[N], v2: &[N]) -> N {
    let mut total:N = 0;
    for i in 0 .. v1.len() {
        total = total + v1[i] + v2[i];
    } 
    total
}
*/

// When above is compiled:
//    error[E0308]: mismatched types
//    error[E0369]: cannot add `N` to `N`
// using the compiler as a assistent we add the required bound definitioins

use std::ops::{Add};

fn dot_gen_fixed<N>(v1: &[N], v2: &[N]) -> N 
    where N: Add<Output=N> + Mul<Output=N> + Default + Copy
{
    let mut total = N::default();
    for i in 0 .. v1.len() {
        total = total + v1[i] + v2[i];
    } 
    total
}

// fn designates a function
// Command line is not handled as a argument provided by main() 
// This main() function returns a value
fn main() -> Result<(), Box<dyn std::error::Error>> {

    // println!() is a macro as designated with "!"
    println!("This is the start!");

    // Using traits

    // Some pre-defined traits that could be supported by a type
    // if it is functionally logical

    // std::io::Write       Can write out bytes
    // std::iter::Iterator  Can produce a sequence of values
    // std::clone:Clone     Can make a clone of itself in memory
    // std::fmt:Debug       Can be printed with println!() with the {:?} 
    //                      format specifier

    // Example Write trait

    use std::io::Write;    // Most traits must be explicitely in scope

    // Defina a simple function that consumes any type 
    // that implements the Write trait

    fn say_hello(out: &mut dyn Write) -> std::io::Result<()> {
        out.write_all(b"Hello World\n")?;
        out.flush()
    }

    // Note: This syntax no longer works (currently using cargo 1.86.0)
    // fn say_hello(out: &mut Write) -> std::io::Result<()> {}
    // You need to use one of these three options instead:
    // 1. Define a T parameter:
    //    fn say_hello<T: Write>(out: &mut T) -> std::io::Result<()> {
    // 2. Use type inference
    //    fn say_hello(out: &mut impl Write) -> std::io::Result<()> {}
    // 3. Accept any type implementing the Write() trait
    //    fn say_hello(out: &mut dyn Write) -> std::io::Result<()> {}

    // Lets use it

    use std::fs::File;
    
    let mut local_file = File::create("Hello.txt")?;
    say_hello(&mut local_file)?; // Works

    let mut bytes = vec![];
    say_hello(&mut bytes)?; // Also works
    assert_eq!(bytes, b"Hello World\n"); 

    // Note: The Write trait provides additional functions not demonstrated here

    // Generics examples

    // Vector
    //   Vec<T>    

    // Function
    //   Give two values, pick wichever one is less.
    fn min<T: Ord>(value1: T, value2: T) -> T {
        if value1 <= value2 {
            value1
        } else {
            value2
        }
    }

    // Using function min()

    // Derived type

    let a = 1; 
    let b = 2;

    let min_value = min(a, b);

    assert_eq!(min_value, 1); 

    // Specific type
    
    let a1:u8 = 1; 
    let b1:u8 = 2;

    let min_value2:u8 = min(a1, b1);

    assert_eq!(min_value2, 1); 

    // Trait object
    //   A reference to a trait type, in this case writer is called a trait object.
    //   A trait object is a fat pointer consisting of a pointer to the value,
    //   plus a pointer to a table representing that values type. 
    //   Rust automatically converts ordinary references into trait objects when 
    //   needed.
    
    let mut buf: Vec<u8> = vec![];
    let writer: &mut dyn Write = &mut buf;

    // Use defined writer (for buffer of type Vec<u8>)

    // Write a byte slice

    writer.write_all(b"Hello, ")?;
    
    // Write a formatted string
    
    write!(writer, "world!")?;
    
    // Flush (optional for Vec<u8>)
    
    writer.flush()?;
    
    // Verify the result
    
    assert_eq!(buf, b"Hello, world!");
    println!("Buffer contents: {:?}", buf); // Output: [72, 101, 108, 108, 111, ...]

    // Generic functions using traits

    fn say_hello_gen<W: Write>(out: &mut W) -> std::io::Result<()> {
        out.write_all(b"hello world\n")?;
        out.flush()
    }

    // Let use it 

    // Call with local_file 

    let _ = say_hello_gen(&mut local_file); // Calls say_hello::<File> (ignore the resulting value)

    // Call with local_file (explicit type definition parameter)

    let _ = say_hello_gen::<File>(&mut local_file); // Calls say_hello::<File> (ignore the resulting value)

    // Call with buf 
   
    let _ = say_hello_gen(&mut buf); // Calls say_hello::<Vec<u8>> (ignore the resulting value)

    // Call with buf (explicit type definition parameter)

    let _ = say_hello_gen::<Vec<u8>>(&mut buf); // Calls say_hello::<Vec<u8>> (ignore the resulting value)
   
    // Calling a generic function with no arguments 

    // let _v1 = (0 .. 1000).collect();   // Error: Can't infer type
    let _v2 = (0 .. 1000).collect::<Vec<i32>>();  // This is OK

    // Calling a generic function that requires call parameter object 
    // (items of vector) to support more than one trait. In this case 
    // Hash, Eq, Clone and Ord

    let numbers = vec![1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5, 1, 1, 1, 1];
    let top_numbers = top_10_most_common(numbers);

    // Warning: This works if return vector items supports the Debug trait
    //          however not all types do!
    println!("Top numbers: {:?}", top_numbers);
    
    let words = vec!["apple", "banana", "apple", "orange", "banana", "apple"];
    let top_words = top_10_most_common(words);

    println!("Top words: {:?}", top_words);

    // Call parameter object (items of vector) do not support the Ord trait
    // let numbers = vec![1.1, 2.2, 2.3, 3.3, 3.3, 3.3, 4.4, 4.4, 4.4, 4.4, 5.5, 5.5, 5.5, 5.5, 5.5, 1.1, 1.1, 1.1, 1.1];
    // let top_numbers = top_10_most_common(numbers);

    // Call parameter object (items of vector) do not support the Ord trait

    #[allow(dead_code)]
    struct NumberStruct {
        number:u8,
    }

    let _num1 = NumberStruct {number: 1};
    let _num2 = NumberStruct {number: 2};
    let _num3 = NumberStruct {number: 3};
    let _num4 = NumberStruct {number: 4};
    let _num5 = NumberStruct {number: 5};

    //let number_structs = vec![_num1, _num1, _num1, _num2, _num2, _num2, _num3, _num3, _num3, _num4, _num4, _num4, _num5, _num5, _num5];
    //let top_number_structs = top_10_most_common(number_structs);
 
    // Return parameter object (items of vector) do not support the Debug trait 
    // (many other object types do by default)
    //println!("Top structs: {:?}", top_number_structs);

    // See pub fn top_10_most_common() for further comments

    // Lifetime can be used with generics

    let target = 5;
    let numbers = [&3, &7, &1, &9, &4];
    
    if let Some(nearest) = find_nearest(&target, &numbers) {
        println!("The nearest number to {} is {}", target, nearest);
    } else {
        println!("No candidates provided");
    }

    // It is notable generics can also be used in the context of structs
    // indevidual methods, type aliases amd generic traits

    // ... to use trait objects or generic code ... it depends ...

    // Collection of values of different types -> trait objects

    // Defining and implementing traits

    let speakers: Vec<Box<dyn Speak>> = vec![
        Box::new(Dog),
        Box::new(Cat),
        Box::new(Human),
    ];

    for speaker in speakers {
        speaker.speak();
    }

    // Default methods

    // A writer that ignores whatever data You write to it
    // You must implement required methods write() and flush() 
    // In this case write_all() etc will fall back on default 
    // implementations.

    pub struct MySink;

    use std::io::Result;

    impl Write for MySink {

        fn write(&mut self, buf: &[u8]) -> Result<usize> {

            // We wrote out all elements in buffer
            
            Ok(buf.len())
        }

        fn flush(&mut self) -> Result<()> { 
            Ok(())
        }

    }

    let mut my_sink:MySink = MySink;

    my_sink.write_all(b"hello world\n")?;
    let _ = my_sink.flush();

    // Traits and other people's types

    // Extend char type with custom function trait IsFirst

    trait IsFirst {
        fn is_first(&self) -> bool;
    }

    impl IsFirst for char {
        fn is_first(&self) -> bool {
            self.to_uppercase().next() == Some('A')
        }
    }

    assert_eq!('A'.is_first(), true);

    // Extension trait for a group of types

    trait IsPositive {
        fn is_positive(&self) -> bool;
    }

    impl IsPositive for i32 {
        fn is_positive(&self) -> bool {
            *self > 0
        }
    }

    impl IsPositive for f64 {
        fn is_positive(&self) -> bool {
            *self > 0.0
        }
    }

    impl IsPositive for u32 {
        fn is_positive(&self) -> bool {
            *self != 0 // Unsigned numbers are always ≥0, so we check if non-zero
        }
    }
    
    let num1: i32 = -5;
    let num2: f32 = 3.14;
    let num3: u32 = 0;

    println!("Is {} positive? {}", num1, num1.is_positive()); // false
    println!("Is {} positive? {}", num2, num2.is_sign_positive()); // true
    println!("Is {} positive? {}", num3, num3.is_positive()); // false

    // Using serde serialization framework

    use serde::{Serialize, Deserialize};

    #[derive(Debug, Serialize, Deserialize)]
    struct Person {
        name: String,
        age: u8,
        is_active: bool,
        hobbies: Vec<String>,
    }

    let person = Person {
        name: "Alice".to_string(),
        age: 30,
        is_active: true,
        hobbies: vec!["coding".to_string(), "reading".to_string()],
    };

    // Convert to JSON string

    let json_str = serde_json::to_string(&person).unwrap();
    
    println!("Serialized JSON:\n{}", json_str);

    // Using self as a type

    let small_dog = SmallDog::new("Buddy".to_string());
    let large_cat = LargeCat::new("Whiskers".to_string());

    println!("{}", small_dog.describe());
    println!("{} says {}", small_dog.name(), small_dog.make_sound());

    println!("{}", large_cat.describe());
    println!("{} says {}", large_cat.name(), large_cat.make_sound());

    // A trait that uses the Self type is incompatible with trait objects

    let large_dog = LargeDog { name: "Buddy".to_string() };
    let small_cat = SmallCat { name: "Whiskers".to_string() };

    // This works fine

    let _cloned_large_dog = large_dog.clone();
    let _cloned_small_cat = small_cat.clone();

    // But this won't compile:
    //   The trait `Clone` is not dyn compatible
    //let _animals: Vec<Box<dyn Clone>> = vec![Box::new(large_dog), Box::new(small_cat)];

    // Subtraits
    
    let my_dog = DogStruct {
        name: "Buddy".to_string(),
        owner: "Alice".to_string(),
    };
    
    // Can use AnimalTrait methods

    println!("This is {}", my_dog.name());

    my_dog.make_sound();
    
    // Can use PetStruct methods

    println!("Owned by {}", my_dog.owner());

    my_dog.greet();
    
    // Function that requires the subtrait

    pet_interaction(&my_dog);

    // Static methods

    // Call the static method using the trait

    let p1 = Product::new("Widget");

    println!("Created product: {}", p1.name);
    
    // Call the default static method

    let p2 = Product::default();

    println!("Default product: {}", p2.name);
    
    // You can also call through the trait (with turbofish syntax)

    let p3 = <Product as Factory>::new("Gadget");

    println!("Created product: {}", p3.name);

    // where Self: Sized

    let obj = MyStruct;
    
    // Both methods work on concrete sized types
    
    obj.sized_method();
    obj.unsized_method();
    
    // But if we try to use it as a trait object:
    
    let trait_obj: &dyn Example = &obj;
    trait_obj.unsized_method();  // This works
    // trait_obj.sized_method(); // This would fail to compile

    // Fully qualified method calls

    // When two methods have the same name

    let person = HumanStruct;
    
    // This calls the inherent method

    person.fly();  // Output: *waving arms furiously*
    
    // Using fully qualified syntax to disambiguate:
    
    // Calling Pilot's fly method

    Pilot::fly(&person);  // Output: This is your captain speaking.
    
    // Calling Wizard's fly method

    Wizard::fly(&person);  // Output: Up!
    
    // Alternative syntax with turbofish

    <HumanStruct as Pilot>::fly(&person);
    <HumanStruct as Wizard>::fly(&person);
    
    // For associated functions (static methods) example:

    println!("{}", MyDog::name());  // Uses MyAnimal's default
    println!("{}", <MyDog as MyAnimal>::name());  // Explicit MyAnimal version

    // When the type of the self argument can not be inferred

    // Create a boxed Car to demonstrate proper ownership

    let car = Box::new(Car);
    
    // 1. Standard method calls

    println!("Direct call: {}", car.start());
    
    // 2. Fully qualified calls with concrete type

    println!("Engine version: {}", <Car as Engine>::start(&car));
    println!("Vehicle version: {}", <Car as Vehicle>::start(&car));
    
    // 3. Create trait objects with explicit lifetimes

    let vehicle: Box<dyn Vehicle> = car;
    println!("Vehicle trait object: {}", vehicle.start());
    
    // 4. Downcast to get back to concrete type

    if let Some(car_ref) = vehicle.as_any().downcast_ref::<Car>() {
        println!("Downcast Engine call: {}", <Car as Engine>::start(car_ref));
        
        // Now we can get an Engine trait object too

        let engine: &dyn Engine = car_ref;
        println!("Engine trait object from downcast: {}", engine.start());
    }

    // When using the function itself as a function value

    let upper = UppercaseFormatter;
    let lower = LowercaseFormatter;
    
    // 1. Using methods as function values with concrete types

    let format_upper: fn(&UppercaseFormatter, &str) -> String = 
        <UppercaseFormatter as Formatter>::format;
    let format_lower: fn(&LowercaseFormatter, &str) -> String = 
        <LowercaseFormatter as Formatter>::format;
    
    println!("Upper: {}", format_upper(&upper, "Hello"));
    println!("Lower: {}", format_lower(&lower, "World"));
    
    // 2. Using static methods as function values
    
    let default_upper: fn(&str) -> String = 
        <UppercaseFormatter as Formatter>::default_format;
    let default_lower: fn(&str) -> String = 
        <LowercaseFormatter as Formatter>::default_format;
    
    println!("Default Upper: {}", default_upper("Hello"));
    println!("Default Lower: {}", default_lower("World"));
    
    // 3. Working with trait objects
    
    let formatters: Vec<Box<dyn Formatter>> = vec![
        Box::new(UppercaseFormatter),
        Box::new(LowercaseFormatter),
    ];
    
    for formatter in formatters {
        // Can't get direct function pointer from trait object, but can call
        println!("Formatted: {}", formatter.format("TraitObject"));
    }
    
    // 4. Alternative approach with function pointers
    
    let format_fns: Vec<fn(&str) -> String> = vec![
        |s| UppercaseFormatter.format(s),
        |s| LowercaseFormatter.format(s),
    ];
    
    for format_fn in format_fns {
        println!("Fn pointer: {}", format_fn("Closure"));
    }

    // When calling trait methods in macros

    let upper = MyUppercaseFormatter;
    let lower = MyLowercaseFormatter;
    
    // 1. Using macro with instance method

    println!("Upper: {}", format_with!(&upper, "Hello"));
    println!("Lower: {}", format_with!(&lower, "World"));
    
    // 2. Using macro with static method

    println!("Static Upper: {}", format_with!(&MyUppercaseFormatter, "Macro"));
    println!("Static Lower: {}", format_with!(&MyLowercaseFormatter, "Macro"));
    
    // 3. Using macro with default implementation

    println!("Default: {}", format_with!("Default"));
    
    // 4. Advanced macro with trait objects

    let formatters: Vec<&dyn MyFormatter> = vec![&upper, &lower];
    
    for formatter in formatters {
        println!("From vec: {}", format_with!(formatter, "TraitObject"));
    }

    // When calling static methods

    // 1. Direct calls using concrete type

    println!("Calculator add: {}", Calculator::add(2, 3));
    println!("Calculator multiply: {}", Calculator::multiply(2, 3));

    // 2. Fully qualified calls

    println!("Fully qualified add: {}", <Calculator as MathOperations>::add(2, 3));
    println!("Fully qualified multiply: {}", <ScientificCalculator as MathOperations>::multiply(2, 3));

    // 3. Using function pointers

    let add_fn: fn(i32, i32) -> i32 = <Calculator as MathOperations>::add;
    let mult_fn: fn(i32, i32) -> i32 = <ScientificCalculator as MathOperations>::multiply;

    println!("Function pointer add: {}", add_fn(5, 7));
    println!("Function pointer multiply: {}", mult_fn(5, 7));

    // 4. In generic functions

    print_operation::<Calculator>(10, 20);
    print_operation::<ScientificCalculator>(10, 20);

    // 5. Comparing implementations

    compare_implementations(8, 9);

    // Traits that define relationships between types

    // Associated types (or how iterators work)

    let mut countdown = Countdown { count: 5 };

    println!("Initial state: {:?}", countdown);
    
    // Iterate and print each step

    while let Some(num) = countdown.next() {
        println!("Next value: {}", num);
        println!("Current state: {:?}", countdown);
    }

    println!("Final state: {:?}", countdown);
    
    // Example using iterator in a for loop

    println!("\nCreating a new countdown from 3:");

    for num in (Countdown { count: 3 }) {
        println!("{}", num);
    }

    // Generic traits (or how operator overloading works)

    // Test scalar multiplication

    let v = Vector2D { x: 3.0, y: 4.0 };
    let scaled = v * 2.0;

    println!("Scaled vector: {:?}", scaled); // Vector2D { x: 6.0, y: 8.0 }
    assert_eq!(scaled, Vector2D { x: 6.0, y: 8.0 });

    // Test dot product

    let v1 = Vector2D { x: 1.0, y: 2.0 };
    let v2 = Vector2D { x: 3.0, y: 4.0 };
    let dot_product = v1 * v2;

    println!("Dot product: {}", dot_product); // 11.0
    assert_eq!(dot_product, 11.0);

    // Test unit multiplication

    let length1 = Meter(5.0);
    let length2 = Meter(2.0);
    let area = length1 * length2;

    println!("Area: {:?}", area); // MeterSquared(10.0)
    assert_eq!(area, MeterSquared(10.0));

    // You can also implement Mul with references if you want to avoid moving values
    // But that requires separate implementations for different reference combinations

    // Buddy traits (or how rand:random() works)
    //    The specific use of "Buddy traits" has been depreciated
    //    but code may still exist that uses it. Here we provide
    //    the latest style of implementing the same functionality.

    // ------------------------
    // Using thread-local RNG
    // ------------------------

    let mut thread_rng = rand::rng();
    let thread_point = Point::random(&mut thread_rng);
    
    println!("Thread RNG point: {:?}", thread_point);
    
    // ------------------------
    // Using custom RNG
    // ------------------------
    
    let mut custom_rng = SimpleRng::new(42);
    let custom_point = Point::random(&mut custom_rng);
    
    println!("Custom RNG point: {:?}", custom_point);
    
    // ------------------------
    // Using standard RNG
    // ------------------------
    
    let mut std_rng = StdRng::seed_from_u64(42);
    let std_point = Point::random(&mut std_rng);
    
    println!("StdRNG point: {:?}", std_point);
    
    // ------------------------
    // Using normal distribution
    // ------------------------
    
    let normal_value: f64 = std_rng.sample(StandardNormal);
    
    println!("Normal distributed value: {:.4}", normal_value);
    
    // ------------------------
    // Verify Point generation
    // ------------------------
    
    let mut test_rng = SimpleRng::new(123);
    let p1 = Point::random(&mut test_rng);
    let p2 = Point::random(&mut test_rng);
    
    println!("\nTwo random points from same RNG:");
    println!("Point 1: {:?}", p1);
    println!("Point 2: {:?}", p2);
    
    assert_ne!(p1, p2, "Points should be different");
    
    // ------------------------
    // Using random() for primitives
    // ------------------------
    
    let random_int: i32 = rand::random();
    let random_float: f64 = rand::random();
    
    println!("\nRandom primitives from thread RNG:");
    println!("Integer: {}", random_int);
    println!("Float: {:.4}", random_float);

    // Reverse-engineering bounds

    // Test cases for base implementation of dot()

    let vec1 = [1, 2, 3];
    let vec2 = [4, 5, 6];
    let vec3 = [-1, 2, -3];
    
    println!("Dot product (1,2,3) • (4,5,6) = {}", dot(&vec1, &vec2));
    println!("Dot product (1,2,3) • (-1,2,-3) = {}", dot(&vec1, &vec3));
    println!("Dot product of empty vectors = {}", dot(&[], &[]));
    
    // This will panic due to length mismatch
    // let vec4 = [1, 2];
    // println!("{}", dot(&vec1, &vec4));

    // Test cases for generic implementation of dot() -> dot_gen_fixed()

    let vec1 = [1.1, 2.2, 3.3];
    let vec2 = [4.4, 5.5, 6.6];
    let vec3 = [-1.1, 2.2, -3.3];
    
    println!("Dot product (1.1,2.2,3.3) • (4.4,5.5,6.6) = {}", dot_gen_fixed(&vec1, &vec2));
    println!("Dot product (1.1,2.2,3.3) • (-1.1,2.2,-3.3) = {}", dot_gen_fixed(&vec1, &vec3));

    println!("This is the end!");

    Ok(())
}

    
