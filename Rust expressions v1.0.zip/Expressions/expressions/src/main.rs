fn positive_number(number:i32) -> bool {
    if number >= 0 {
        return true;
    }    
    else
    {
        return false;
    }
}

fn _coverage(number: i32) {
    loop {
        if number == 1 {
            return;
        }
    }    
}

fn _loop_forever() -> ! {
    loop {

    }
}

// Player is a Rust style 'Class' implemented using:
//    Struct Player
//    impl Player 

struct Player {
    name:String
    
}

impl Player {

    fn new(name:String) -> Player {
        Player {name}
    }
    
    fn location(&self) -> i32 {
        1
    }
}

fn main() {
    println!("Hello, expressions!");

    // Expressions return values 

    //  Expression that ruturns a numeric value:

    let result: u8;

    result = {
        let first_value = 1;
        let second_value = 1;
        first_value+second_value 
    };

    assert_eq!(result, 2);
    
    //  An if expression can be used to initialize a variable:
    
    let is_ok = {result == 2};

    assert_eq!(is_ok, true);

    //  A match expression can be passed as an argument to a function or macro:

    println!("The number is positive: {}",
        match positive_number(2) {
            true => "TRUE",
            false => "FALSE"
        });

    // Rust does not have C's ternary operator (expr1 ? expr2 : expr3)

    // A block produces a value and can be used anywhere a value is needed:
    
    let mut is_positive = match positive_number(2) {
        true => true,
        false => {

            // Function declarations can be used

            fn negative_number(number:i32) -> bool {
                if number < 0 {
                    return true;
                }    
                else
                {
                    return false;
                }
            }

            let is_negative = negative_number(-1);

            is_negative  // This value is returned

        }  // No semicolon here
    };

    assert_eq!(is_positive, true);

    // Rust prohibits match expressions that do not cover all possible values:

    is_positive = match positive_number(2) {
        true => true,
        false => false   // Comment out -> Error nonexhaustive pattewrns
    };         

    assert_eq!(is_positive, true);

    // All blocks of an if expression must produce values of the same type:

    let mut positive_sign = if positive_number(2) { true } else { false };    // OK

    assert_eq!(positive_sign, true);

    // positive_sign = if positive_number(2) { true } else { 0 };   // Uncomment -> Error
    positive_sign = false;  // Comment out

    assert_eq!(positive_sign, true);

    // One more form of if the "if let" expression:

    let some_value: Option<i32> = Some(42);

    if let Some(x) = some_value {
        println!("The value is: {}", x);
    } else {
        println!("No value present");
    }

    // Another example with a different type

    let day = "Monday";

    if let "Monday" = day {
        println!("It's the start of the work week!");
    } else {
        println!("It's not Monday");
    }

    /*
    An "if let" expression is shorthand for a match with just one pattern:

        match expr {
            pattern => { block1 }
            _ => { block2 }
        }
    */

    // There are four looping expressions:

    let condition = true;

    // while

    while condition {
        // loop logic... 
    }

    // while let 
    
    // Example 1: Pop values from the stack

    let mut stack = vec![1, 2, 3, 4, 5];

    while let Some(top) = stack.pop() {
        println!("Current top value: {}", top);
    }

    println!("Stack is now empty");

    // Example 2: Iterate over a string
   
    let mut iter = "hello".chars();

    while let Some(c) = iter.next() {
        println!("Next character: {}", c);
    }

    // loop

    loop {
        // loop logic...
        break;
    }

    // for pattern in collection

    let numbers = vec![1, 2, 3, 4, 5];
    
    for num in &numbers {
        println!("Number: {}", num);
    }

    // Note that loop expressions only return ().

    // The condition must pruduce type bool.

    // Define a loop over a range:
    //   0..20 is the same as std::ops::Range { start: 0, end: 20 }

    for i in 0..20 {
        println!("{}", i);
    }

    // Last number printed is 19.

    // For loop over a value consumes it:

    let strings = vec!["A", "B", "C"];

    for s in &strings {     // If You remove '&' (is reference) each String is moved into s here...
        println!("{}", s);
    }       // ...and dropped here
    
    println!("{} error(s)", strings.len());   // error: use of moved value 

    // For s in &mut strings {...}   <-- reference to mutable collection

    // In Rust break only works in loops.

    // A continue expression jumps to the next loop iteration.

    // A loop can be labeled with a lifetime:

    'search:
    for string in strings {
        for letter in string.chars() {
            if letter == 'B' {
                break 'search;
            }
        }
    }

    // Break will exit for room loop.

    // Labels can also be used with continue.

    // return expression has been fully covered in earlier sessions.

    // Code coverage analysis may sometimes fail when using loop expressions:

    // _coverage(2);   // See this call

    // ...however with compiler version in use the above example that should
    // fail does not. This is Rust!

    // Divergent function:

    // _loop_forever();   // See this call
    
    // This function never returns indicated by type !.

    // Function and method calls:

    fn sum(a: i32, b: i32) -> i32{
        a+b 
    }

    let _x = sum(1302, 462);    // Function call

    let mut player = Player::new("John".to_string());  // Static nethod call

    let _room = player.location();      // Method call

    // The . operator makes an automatic dereference.

    // Syntax issue a Rust thinks < is intended:

    // return Vec<i32>::with_capacity(1000);   // Uncomment to see error
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
    // this helps:

    // return Vec::<i32>::with_capacity(1000);  // Uncomment to see error is corrected

    // Prefer type infer by omitting <i32> if possible.

    // Fields and elements:

    player.name = "John".to_string();   // Struct field

    let tuple = (1, 2,);

    let _number_element = tuple.1;    // Tuple element '2'

    // Square brackets access the elements of an array, a slice, or a vector:

    // Access an element using index
    
    let third_element = numbers[2];

    println!("The third element is: {}", third_element);

    // Extracting a slice from an array or vector:

    let slice = &numbers[1..3];

    // Access an element using index

    let third_element = slice[2];

    println!("The third element is: {}", third_element);

    // The value to the left of the brackets is automatically dereferenced.

    /*

    The .. operator allows for the following ranges:
    
        ..      Range full
        a ..    Range from { start: a }
        .. b    Range to { end: b }
        a .. b  Range { start: a, end: b }

    Rust ranges are half-open: they include the start value, if any, but not the end value.

    Only ranges that include a start value are iterable.

    Array slicing however supports all four forms by introducing a default start value.

    */

    // The unary * operator is used to access the value pointed to by the reference.

    let x = 5;

    let y = &x;
    
    println!("Value of x: {}", x);
    
    println!("Value pointed to by y: {}", *y);

    /*

    Arithmetic, Bitwise, Comparison, and Logical Operators observations:

    Integer overflow is detacted in Debug builds and causes a panic.

    You can do unchcked arithmetic with library functions like a-wrapping_add(b).

    Checked divide by zero a.checked_div(b) returns amd Option (None if b is zero).

    Unary - negates a number (accepts unsigned integer).

    Bitwise NOT uses !.

    Bit shifting is always sign-extending on signed integer types and zero-extending 
    on unsigned integer types.

    Bitwise operations have higher precedence than comparisons.

    When comparing (==, !=, <, <=, > and >=) two types they must have the same type.

    && and || types must be bool.

    Note: C's increment and decrement operators ++ and -- are not supported

    Type casts:

        let x = 17;               x is type i32
        let index = x as usize;   Convert to usize

    Number may be cast from any of the built in numeric types to any other.

    Values of type bool, char, or of C-like enum type, may be cast to any 
    integer type.

    Some casts involving unsafe pointer types are allowed.

    If type implements the Deref trait some casts may accure automatically.
    
    See documentation for further details.

    */

    // Closures:

    // Lightweight function-like values

        let is_even = |x| x % 2 == 0;

        assert_eq!(is_even(14), true);

    // Precedence and Associativity:

    // See related tables in documentation 

}
