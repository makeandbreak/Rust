extern crate calc_seperate_lib;

#[test]
fn add() {
    println!("{}", (calc_seperate_lib::add_functions::add(1.1, 2.2) * 10.0).round() / 10.0);

    assert!(((calc_seperate_lib::add_functions::add(1.1, 2.2) * 10.0).round() / 10.0) == 3.3);
}

#[test]
fn subtract() {
    println!("{}", calc_seperate_lib::subtract_functions::subtract(2.0, 1.5)); 

    assert!(calc_seperate_lib::subtract_functions::subtract(2.0, 1.5) == 0.5);
}
