
// We want to use module defiened in sepeate file
mod calc_seperate;

// We want to use modules defined in directory calc_seperate_dir file mod.rs
mod calc_seperate_dir;

// We want to use libraries defined in directory calc_seperate_lib file lib.rs
extern crate calc_seperate_lib;

mod calc_local {

    pub fn add(a:f32, b:f32) -> f32 {
        a+b
    }

    pub fn subtract(a:f32, b:f32) -> f32 {
        a-b
    }

    pub fn use_private_subtract(a:f32, b:f32) -> f32 {
        internal_math::subtract(a, b)

        // Can not access as not public
        // internal_math::subtract_not_public(a, b)

    }

    fn _multiply(a:f32, b:f32) -> f32 {
        a*b
    }

    mod internal_math {

        pub fn subtract(a:f32, b:f32) -> f32 {
            subtract_not_public(a, b)
        }

        fn subtract_not_public(a:f32, b:f32) -> f32 {
            a-b
        }

        // Will not work as calc_local can not be referenced in this context
        // Do not recommend this even if it was possible
        // fn multiply(a:f32, b:f32) -> f32 {
        //    calc_local::multiply(a, b)
        // }
    
    }

}

/// This line will be included in documentation
pub fn _docme1() {}

#[doc = "This line will be included in documentation"]
pub fn _docme2() {}

// fn designates a function
// Command line is not handled as a argument provided by main() 
// This main() function does not return a value
/// We can add HTML formatting *this text in italics* and _this text in italics_
/// We can add HTML formatting **this text in bold**
/// We can add any HTML directive <b>this text in bold</b> to control formatting
/// 
fn main() {
    //! This line will be included in documentation attached to enclosing main()
    

    // println!() is a macro as designated with "!"
    println!("This is the start!");

    // Modules

    let mut c = calc_local::add(1.1, 2.2);

    c = calc_local::subtract(c, 1.5);

    // Can not access as function `subtract` is not publicly re-exported
    // c = calc_local::internal_math::subtract(c, 1.5);

    // Can not access as function `multiply` is not public
    // c = calc_local::_multiply(c, 1.5);

    c = calc_local::use_private_subtract(c, 1.5);

    println!("Result: {}", c);

    // Modules in seperate file
 
    let mut c = calc_seperate::add(1.1, 2.2);

    c = calc_seperate::subtract(c, 1.5);

    // Can not access as function `subtract` is not publicly re-exported
    // c = calc_seperate::internal_math::subtract(c, 1.5);

    // Can not access as function `multiply` is not public
    // c = calc_seperate::_multiply(c, 1.5);
     
    c = calc_seperate::use_private_subtract(c, 1.5);

    println!("Result: {}", c);

    // Using modules in a seperate directory
    
    // calc_seperate_dir   Reference to modules defined in ..\calc_seperate_dir\mod.rs
    // add()               Function add() made available from add_functions by 
    //                     ..\calc_seperate_dir\mod.rs
    // ...there could be other varients of add() all grouped under the add_functions module
    let mut c = calc_seperate_dir::add(1.1, 2.2);

    c = calc_seperate_dir::subtract(c, 1.5);

    println!("Result: {}", c);

    // Paths and imports
    
    // Using absolute module path ::...

    let pival = ::std::f64::consts::PI;
    
    println!("Result: {}", pival);

    // 'use' options

    // Recommended
    // use std::f64::consts
    //  let pival = consts::PI;

    // Not recommended
    // use std::f64::consts::PI;
    //  let pival = PI;

    // Access all consts values
    // use std::f64::consts::*;
    //  let pival = PI;

    // The standard prelude

    // Automatically linked
    //   extern crate std;

    // Allways present
    //   use std::prelude::v1::*;
    
    // If 'prelude' is present as module tree it is suggested 
    // importing should be done with '::*'

    // Items - The building blocks of Rust

    // Functions
    //   Already covered earlier

    // Built in types 
    //   Already covered earlier

    // User-defined types: struct, enum and trait

    // Struct declaration

    struct _Person {
        name: String,
        age: u32,
    }

    // Enum declaration

    enum _Color {
        Red,
        Green,
        Blue,
        Custom(u8, u8, u8),
    }

    // Trait declaration

    trait _Drawable {
        fn draw(&self);
        fn get_area(&self) -> f64;
    }

    // Type aliases

    type UnsignedInteger8 = u8;

    let _d:UnsignedInteger8 = 1;

    // impl blocks

    struct _Circle {
        radius: f64,
    }

    impl _Drawable for _Circle {
        fn draw(&self) {
            println!("Drawing a circle with radius {}", self.radius);
        }

        fn get_area(&self) -> f64 {
            std::f64::consts::PI * self.radius * self.radius
        }
    }

    // Constants

    pub const _TOP_TEMP:f64 = 21.3;

    // static is a value that exist for duration of program
    //   Already covered earlier

    pub static mut _TEMP_HOLD:f64 = 29.5;

    // However this will fail 

    // _TEMP_HOLD = 20.5;

    // Modules
    //   Already covered earlier

    // Imports
    //    See calc_seperate_dir\mod.rs use statements

    // extern block
    //    Declare none Rust blocks (will be covered later)

    // Defining and using a library

    // Using library in a seperate directory
    
    // calc_seperate_lib   Reference to modules defined in ..\calc_seperate_dir\mod.rs
    // add()               Function add() made available from add_functions by 
    //                     ..\calc_seperate_lib\lib.rs
    // ...there could be other varients of add() all grouped under the add_functions module
    let mut c = calc_seperate_lib::add_functions::add(1.1, 2.2);

    c = calc_seperate_lib::subtract_functions::subtract(c, 1.5);

    println!("Result: {}", c);

    // The src\bin directory

    // You can also use this layout if You only need a basic layout:
    //   src\* Library files (including lib.rs)
    //   src\bin\main.rs containing 'use [project name];'
    // See "Rust crates and modules simple v1.0.zip"

    // The library can also be created in it's own project if it makes more sense
    //   Already covered earlier

    // Attributes

    // #[allow] example

    #[allow(unused_variables)]
    #[allow(non_snake_case)]
    let NOTUSED_NoGood_Name:u8;

    // #[cfg] example
    //   See documentation for all options

    #[cfg(windows)]
    #[allow(unused_variables)]
    let running_windows:bool = true;   // Use this on Windows only

    // #[inline]   Inline code (is taken as suggestion by compiler) or not 

    // #[inline(allways)]
    // fn inline_me() {...}

    // #[inline(never)]
    // fn never_inline_me() {...}

    // #[test]   Defines a test
    // fn test() {...}

    // #![]   Apply attribute to all valid targets in scope

    // #[feature]   Enable a experimental deature
    // #[feature(i512_type)]

    // Tests and Documentation
    //   Already covered earlier but we left out a few details

    // #[should_panic]    We can have a test that is expected to panic

    // #[test]  
    // #[should_panic(expected="divide by zero")]
    // fn test() {.../0.0} 

    // Tricky: Tests are run multithreaded by default
    //         Use RUST_TEST_THREADS = 1 
    //         to disable this.

    // Integration tests

    // See ..\tests\test.rs for example of library API testing

    // Documentation
    
    // Create HTML documentation for Your project
    
    // cargo --no-deps --open
    // --no-deps   Only create documentation for current project
    // --open      Open in browser when done
    // Documentation is creates in ...\target\doc
    // Start page for this project ...\target\doc\crates_modules\index.html                          
    // Hint: In this project You can use "crates_modules_doc.cmd"
    
    // Documentation declarations 
    // These can be applied to any pub feature 
    // See _docme?() above main() 

    //'/ This line will be included in documentation
    // See _docme1() above main()

    // #[doc = "This line will be included in documentation"]
    // See _docme2() above main()

    // '//!' -> #![doc] attach comment to enclosing feature 

    //'/ We can add HTML formatting *this text in italics* and _this text in italics_ 
    
    //'/ We can add HTML formatting **this text in bold** 

    //'/ We can add any HTML directive <b>this text in bold</b> to control formatting

    // Code provided in Rust comments is extracted and defined as tests
    // See main example here: ...\calc_separete_lib\add_functions.rs
    // Run using crates_modules_doc.cmd and then crates_modules_test.cmd

    // A block of code in a doc comment

    //'/
    //'/      let d:u8 = 11;
    //'/      println!("The number is {}", d);
    //'/

    // A block of code in a doc comment (raw unformated):
    
    //'/ 
    //'/ '''
    //'/ let d:u8 = 11;
    //'/ println!("The number is {}", d);
    //'/ '''

    // Comment out code in a doc comment 

    //'/ 
    //'/ ```
    //'/ let d:u8 = 11;
    //'/ # println!("The number is {}", d);
    //'/ ```
   
    // Mark code in doc comment as none executable 

    //'/ 
    //'/ ```no_run
    //'/ let d:u8 = 11;
    //'/ # println!("The number is {}", d);
    //'/ ```

     // A block of code in a doc comment - Full program

    //'/      fn main(){
    //'/          let d:u8 = 11;
    //'/          println!("The number is {}", d);
    //'/      }

    // Specifying dependencies in Cargo.toml
    //   Already covered earlier but we left out a few details

    // Get dependency from Github repository

    // image = { git = "https://github.com/Piston/image.git", rev = "528f119c" }
    // You can use rev, tag or branch

    // Get dependency from directory

    // image = { path = ".../image" }
    
    // Versions

    // This is considered a target version actual selection
    // is based on rules defined here http://semver.org/
    // image = "0.6.1"

    // Overrides 

    // image = "=0.6.1"
    // image = ">=0.6.1"
    // image = ">0.6.1 <1.1.9"
    // image = "<=2.7.10"
    // image = "0.6.*"

    // See http://doc.crates.io/crates-io.html for more details
   
    // Cargo.lock

    // Contains information on specific dependency versions being used

    // WARNING: Dependency versions will only be updated on 'cargo clean/build' 
    //          or 'cargo update'

    // Sometimes it usefull to check the content of this file in a text editor
    // to manually verify what specific versions are being used.

    // Publishing crates to crates.io

    // Check Cargo.toml for hard coded local reference

    // image = { path = ".../image" }
    // optionally replace with dual src address or just version from crates.io:
    // image = { path = ".../image", version = 0.6.1 }
    // image = "0.6.1"

    // Package 

    // cargp package
    // Hint: In this project You can use "crates_modules_package.cmd"
    // Handle all manifest warnings 
    //   Example: warning: manifest has no description, license, ...

    // Get user account on crates.io
    
    // Login using "Account Settings" page login command

    // cargo login [key]

    // Publish crate

    // cargo publish

    // Hint: In this project You can use "crates_modules_publish.cmd"
    //       Update '[key]' first

    // Workspace

    // You can create a folder with subfolders containg crates

    // root\crate1\*
    //      crate2\*
    //      crate3\*

    // root\Cargo.toml    Common workspace 
    //    [workspace]
    //    members = ["crate1", "crate2", "crate3"]

    // A few more nice things

    // On publishing docs get generated to http:\\docs.rs

    // Use http://travis-ci.org to automatically test on publish

    // Automate generation of README.md
    //     See cargo-readme at https://crates.io/crates/cargo-readme

    println!("This is the end!");
}




