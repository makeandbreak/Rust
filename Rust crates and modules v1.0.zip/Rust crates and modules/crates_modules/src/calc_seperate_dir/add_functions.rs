pub fn add(a:f32, b:f32) -> f32 {
    // Bring in correction from parent module
    // super represents the parent madule
    a+b+super::CORRECTION
}
