pub const CORRECTION:f32 = 0.001;
pub mod add_functions;
pub mod subtract_functions;

// Make add_functions functions available here
// self is a alias for the current module
pub use self::add_functions::add;
pub use self::subtract_functions::subtract;
