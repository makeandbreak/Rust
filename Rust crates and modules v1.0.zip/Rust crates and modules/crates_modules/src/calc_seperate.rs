pub fn add(a:f32, b:f32) -> f32 {
    a+b
}

pub fn subtract(a:f32, b:f32) -> f32 {
    a-b
}

pub fn use_private_subtract(a:f32, b:f32) -> f32 {
    internal_math::subtract(a, b)

    // Can not access as not public
    // internal_math::subtract_not_public(a, b)

}

fn _multiply(a:f32, b:f32) -> f32 {
    a*b
}

mod internal_math {

    pub fn subtract(a:f32, b:f32) -> f32 {
        subtract_not_public(a, b)
    }

    fn subtract_not_public(a:f32, b:f32) -> f32 {
        a-b
    }

    // Will not work as calc_local can not be referenced in this context
    // Do not recommend this even if it was possible
    // fn multiply(a:f32, b:f32) -> f32 {
    //    calc_local::multiply(a, b)
    // }

}


