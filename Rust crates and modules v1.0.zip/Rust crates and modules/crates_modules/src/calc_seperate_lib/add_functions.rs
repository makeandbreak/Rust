/// A block of code in a doc comment:
///
///     let d:u8 = 11;
///     println!("The number is {}", d);
///     assert_eq!(d, 11);
///
/// ```
/// let d:u8 = 11;
/// println!("The number is {}", d);
/// ```
///    
pub fn add(a:f32, b:f32) -> f32 {
    a+b
}
