// Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {

    // tauri::Builder::default()   
    //     This creates a default Tauri application builder, which is the 
    //     starting point for configuring your Tauri app.
    //
    //   .plugin(tauri_plugin_opener::init())   
    //       This adds the tauri-plugin-opener plugin to the application. This 
    //       plugin allows the app to open files or URLs using the default 
    //       system handler.
    //
    //   .invoke_handler(tauri::generate_handler![greet])    
    //       This sets up a handler for JavaScript-to-Rust function calls. 
    //       The greet function (which is not shown in this snippet) can 
    //       be called from the frontend JavaScript code. The generate_handler! 
    //       macro creates the necessary boilerplate to make this function 
    //       available to the JavaScript side.
    //
    //   .run(tauri::generate_context!())
    //       This runs the Tauri application. The generate_context!() macro 
    //       creates the application context, which includes information from 
    //       your tauri.conf.json file and other build-time constants.
    //
    //   .expect("error while running tauri application")
    //       This handles any errors that might occur when running the application. 
    //       If an error occurs, the program will panic with the specified error message.
    //
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![greet])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
