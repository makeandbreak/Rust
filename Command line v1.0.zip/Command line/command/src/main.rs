// Define 'traits' you want to use
// Traits are collections of methods types can implement
use std::str::FromStr;

// fn designates a function
// Command line is not handled as a argument provided by main() 
// This main() function does not return a value
fn main() {

    // println!() is a macro as designated with "!"
    println!("This is the start!");

    // let is used to a variable
    // ": type" can be used to define type or it can be inferred by compiler
    // args() is a iterator 
    // Note: Some code examples a have used would not compile due to type 
    //       issues. It seems infer rules may have been changing over time
    let args: Vec<String> = std::env::args().collect();

    let usage_msg = "Usage: command ([add][sutract]) list of numbers (minimum of 2)) Example: command add 1 2.0";

    // If clauses do not use brackets ()
    if args.len() < 4 {
        // Send output to stderr()
        // unwrap() is used to handle a writeln!() output failure 

        // This can not be used even if many code examples contaim this syntax
        //   writeln!(std::io::stderr(), "...").unwrap();

        // eprintln!() is used to print to stderr()
        eprintln!("{:?}",usage_msg);

        // We specifically request to exit with return code 1
        std::process::exit(1);
    }

    // & designates 'address of' reference
    // [] is used to access indevidual vector values
    // Type will be infered
    let _function = &args[1];

    println!("{:?}",_function);

    // START - This section caused a false positive in AVG virus scanner

    // Create a vector of valid functions    
    let _functions: Vec<String> = vec!["add".to_string(),"subtract".to_string()]; 

    // Check function is one of the valid ones
    if !_functions.contains(&_function){
        eprintln!("{:?}",usage_msg);
        std::process::exit(1);
    }

    // END 

    // mut defines a mutable variable thet is the value(s) can be changed
    let mut numbers = Vec::new();

    // [3..] start from index 3
    // Index values start from 1
    for arg in &args[2..]{

        // There are no exceptions in Rust
        // type f64 is float 64 and implements function from_str()
        // .expect() is a method of Result object returned by from_str
        // The returned result is "Ok([value])" or "Err([value])". if Ok
        // the [value] will be returned.
        numbers.push(f64::from_str(&arg).expect("error parsing argument"));

        // We print the Result object
        println!("{:?}",f64::from_str(&arg));    
    }

    if _function == "add" {
        let result = add_numbers(numbers);

        println!("add!");
        println!("{:?}",result);
    }
    else
    {
        let result = subtract_numbers(numbers);    

        println!("subtract!");
        println!("{:?}",result);

    };

    println!("This is the end!");
}

// -> sets return type
// Compiler may somewhat randomly request a '_' prefix be used for variable names
fn subtract_numbers(_numbers: Vec<f64>) -> f64 {
    let mut result = _numbers[0];

    for number in &_numbers[1..]{
        result -= number;
    }

    // We return without a Return() statement just a value without ";"
    result
}

// #[test] defines a test
#[test]
fn subtract_numbers_test(){

    // assert(s) are used to check for specific conditions
    // vec! specifies a vector type
    assert_eq!(subtract_numbers(vec![2.0, 2.0]), 0.0)

}

// -> sets return type
// Compiler may somewhat randomly request a '_' prefix be used for variable names
fn add_numbers(_numbers: Vec<f64>) -> f64 {
    let mut result = _numbers[0];

    for number in &_numbers[1..]{
        result += number;
    }

    // We return without a Return() statement just a value without ";"
    result
}

#[test]
fn add_numbers_test(){

    assert_eq!(add_numbers(vec![2.0, 2.0]), 4.0)

}