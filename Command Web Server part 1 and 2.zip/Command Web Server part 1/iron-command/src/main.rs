// Use external 'crate' iron
// List of crates: https://github.com/rust-lang/crates.io-index
// iron versions:  https://github.com/rust-lang/crates.io-index/blob/55442915e302b2de11afb701a779d53593170d94/ir/on/iron#L4
// iron current: 0.5.1
// iron latest: 0.6.1
extern crate iron;
// Use external 'crate' mime including macro definitions
#[macro_use] extern crate mime;

// Use all traits '*' from iron::prelude
use iron::prelude::*;
use iron::status;

fn main() {
    println!("Serving on http://localhost:3000...");

    // Create a page server defined by get_form
    Iron::new(get_form).http("localhost:3000").unwrap();    
}

fn get_form(_request: &mut Request) -> IronResult<Response> {

    // New responce object
    let mut response = Response::new();

    // Build response in form of a standard HTML5 header/page

    // Status
    // On the wire (header): 'HTTP/1.1 200 OK'
    response.set_mut(status::Ok);

    // mime as in content and charset
    // On the wire (header): 'Content-Type: text/html; charset=UTF-8'
    response.set_mut(mime!(Text/Html; Charset=Utf8));
    
    // Actual page
    // On the wire (page): As is
    response.set_mut(r#"
        <title>GCD Calculator</title>
        <form action="/calculate" mothod="post">
            <input type="text" name="n"/>
            <input type="text" name="n"/>
            <input type="text" name="n"/>
            <input type="text" name="n"/>
            <button type="submit">Add</>
            <button type="submit">Subtract</>
        </form>
    "#);

    // Return response wrapped in Ok()
    Ok(response)

}