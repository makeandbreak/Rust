// Use traits defined in FromStr
use std::str::FromStr;

// Use external 'crate' iron
// List of crates: https://github.com/rust-lang/crates.io-index
// iron versions:  https://github.com/rust-lang/crates.io-index/blob/55442915e302b2de11afb701a779d53593170d94/ir/on/iron#L4
// iron current: 0.5.1
// iron latest: 0.6.1
extern crate iron;
// Use external 'crate' mime including macro definitions
#[macro_use] extern crate mime;

// Use all traits '*' from iron::prelude
use iron::prelude::*;
use iron::status;

// Use Router
extern crate router;
use router::Router;

// Use urlencoded
extern crate urlencoded;
use urlencoded::UrlEncodedBody;

fn main() {
    
    // Create a router
    let mut router = Router::new();

    // Define handler for get "/"
    router.get("/", get_form, "root");

    // Define handler for get "/favicon.ico"
    router.get("/favicon.ico", get_favicon, "favicon.ico");

    // Define handler for get "/add"
    router.post("/add", post_add, "add");

    // Define handler for get "/subtract"
    router.post("/subtract", post_subtract, "subtract");

    println!("Serving on http://localhost:3000...");

    // Create a page server where routing is handled using router
    Iron::new(router).http("localhost:3000").unwrap();    

}

fn get_favicon(_request: &mut Request) -> IronResult<Response> {

    println!("get_favicon: START");

    // New responce object
    let mut response = Response::new();

    // Build response in form of a standard HTML5 header/page

    // Status
    // On the wire (header): 'HTTP/1.1 200 OK'
    response.set_mut(status::Ok);

    // mime as in content and charset
    // On the wire (header): 'Content-Type: text/html; charset=UTF-8'
    response.set_mut(mime!(Text/Html; Charset=Utf8));

    println!("get_favicon: END");
    println!("");

    // Normal return
    
    Ok(response)

}

fn get_form(_request: &mut Request) -> IronResult<Response> {

    println!("get_form: START"); 

    // New responce object
    let mut response = Response::new();

    // Build response in form of a standard HTML5 header/page

    // Status
    // On the wire (header): 'HTTP/1.1 200 OK'
    response.set_mut(status::Ok);

    // mime as in content and charset
    // On the wire (header): 'Content-Type: text/html; charset=UTF-8'
    response.set_mut(mime!(Text/Html; Charset=Utf8));
    
    // Actual page
    // On the wire (page): As is
    response.set_mut(r#"
        <title>Calculator</title>
        <form id="CalculatorForm">
            <input type="text" name="n"/>
            <input type="text" name="n"/>
            <input type="text" name="n"/>
            <input type="text" name="n"/>

            <button id="add" type="button" onclick="submitForm('add')">Add</button>
            <button id="subtract" type="button" onclick="submitForm('subtract')">Subtract</button>
        </form>

        <script>
        function submitForm(url) {
            const form = document.getElementById('CalculatorForm');
            const formData = new FormData(form);

            // Convert FormData to URLSearchParams
            const urlEncodedData = new URLSearchParams(formData).toString();
            
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: urlEncodedData
            })
            .then(response => response.text()) 
                .then(html => {
                        // Display the HTML response
                        document.documentElement.innerHTML = html;
                    })
                        .catch((error) => {
                                console.error('Error:', error);
                                document.documentElement.innerHTML = 'An error occurred.';
                            });        
            }

        </script>

    "#);

    println!("get_form: END"); 
    println!("");

    // Return response wrapped in Ok()
    Ok(response)

}

fn post_add(request: &mut Request) -> IronResult<Response> {

    println!("post_add: START"); 

    // Create a vector for the numbers
    let mut numbers = Vec::<f64>::new();

    // Extract the numbers
    // Get related reponse 
    let mut response = extract_numbers(request, &mut numbers).expect("error extracting numbers");

    // If no numbers early exit
    if numbers.len() == 0 {

        response.set_mut(status::Ok);
        response.set_mut(mime!(Text/Html; Charset=Utf8));
        response.set_mut("There are no numbers to add!");
    
        // Early return
        return Ok(response);
    }

    // Add numbers

    let mut numbers_sum = numbers[0];
    
    for number in &numbers[1..]{
        numbers_sum += number;
    } 

    // Display result

    response.set_mut(status::Ok);
    response.set_mut(mime!(Text/Html; Charset=Utf8));
    response.set_mut(format!("The sum of the numbers {:?} is: <b>{}</b>\n", numbers, numbers_sum));
 
    println!("post_add: END"); 
    println!("");

    // Return result
    
    Ok(response) 

}

fn post_subtract(request: &mut Request) -> IronResult<Response> {

    println!("post_subtract: START"); 

    let mut numbers = Vec::<f64>::new();

    let mut response = extract_numbers(request, &mut numbers).expect("error extracting numbers");

    if numbers.len() == 0 {

        response.set_mut(status::Ok);
        response.set_mut(mime!(Text/Html; Charset=Utf8));
        response.set_mut("There are no numbers to subtract!");

        // Early return
        return Ok(response);
    }

    let mut numbers_subtraction = numbers[0];
    
    for number in &numbers[1..]{
        numbers_subtraction -= number;
    } 

    response.set_mut(status::Ok);
    response.set_mut(mime!(Text/Html; Charset=Utf8));
    response.set_mut(format!("The subtraction of the numbers {:?} is: <b>{}</b>\n", numbers, numbers_subtraction));

    println!("post_subtract: END"); 
    println!("");

    Ok(response) 
    
}

fn extract_numbers(request: &mut Request, numbers: &mut Vec<f64>) -> IronResult<Response>  {
 
    println!("extract_numbers: START"); 

    // Create a response 
    let mut response = Response::new();

    // Rust match 
    // match something_that_has_a_value (or returns a value) to
    //     Err()    Returned result wrapped in a error
    //     Ok()     Returned result wrapped in a Ok
    //     None()   No values
    //     Some()   Some values
    //     A specific value

    // Extract form data

    let form_data = match request.get_ref::<UrlEncodedBody>(){

                        Err(e) => {
                            response.set_mut(status::BadRequest);
                            response.set_mut(format!("Error parsing form data: {:?}\n", e));

                            // Early return
                            return Ok(response);
                        }
                        
                        Ok(map) => map

    };

    // Get unparsed (raw) numbers

    let unparsed_numbers = match form_data.get("n") {

                                None => {
                                    response.set_mut(status::BadRequest);
                                    response.set_mut(format!("Form data has no 'n' parameters\n"));

                                    // Early return
                                    return Ok(response);
                                }

                                Some(nums) => nums

    };

    // Try and convert raw numbers into real numbers

    for unparsed in unparsed_numbers {
        match f64::from_str(&unparsed){

                Err(_) => {
                    response.set_mut(status::BadRequest);
                    response.set_mut(format!("Value for 'n' parameter not a number: {:?}", unparsed));
                    return Ok(response);
                }
                
                Ok(n) => {
                    numbers.push(n);
                }

        }
    }     
 
    println!("extract_numbers: END"); 
    println!("");

    // Normal return
    
    Ok(response)
}

