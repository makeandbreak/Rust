// slint!{}   A slint macro to convert slint markup usually in 
//            in similar format as CSS or QML to Rust code
slint::slint! {

    // This block is Not Rust code it is slint markup!

    // Import the slint widgets to use
    import { Button, VerticalBox } from "std-widgets.slint";

    // export     Export component to be used outside this module and file
    // component  Defines a component
    // MessageBox The component to be defined
    // inherits   Component will inherit from component
    // Window     Component to inherit from (a slint window)
    export component MessageBox inherits Window {
        
        // Size of message box
        width: 300px;
        height: 200px;

        // Message box title
        title: "Message Box";

        // Define callbacks
        callback show-message();
        callback close-message();

        // Property definition
        // in-out   Is read and write
        // property Define a property
        // <bool>   Property type
        // is-message-visible   Property name
        // false   Initial value
        in-out property <bool> is-message-visible: false;

        // Define widget VerticalBox
        VerticalBox {

            // Set aligmment
            alignment: center;

            // Define widget Button 
            Button {
                text: "Show Message";
                visible: !root.is-message-visible;

                // Connect button clicked to callback show-message()
                clicked => {
                    root.show-message();
                }

            }

            // If message is visible display it
            if root.is-message-visible: VerticalBox {

                // Define widget Text
                Text {
                    text: "This is a message box!";
                    font-size: 16px;
                }

                // Define widget Button
                Button {
                    text: "Close";

                    // Connect button clicked to callback close-message()
                    clicked => {
                        root.close-message();
                    }
                }
            }
        }
    }
}

fn main() {

    // MessageBox::new()  Initializes a new instance of the MessageBox
    // unwrap()   Extracts the Ok value (the instance), panicking (causing a runtime 
    //            crash) if it encounters an error.
    let main_window = MessageBox::new().unwrap();

    // Connect a handler function to the show_message callback
    // {}   A closure (anonymous function) or handler that executes when 
    //      the callback is invoked will be defined in this block
    main_window.on_show_message({

        // main_window   This is a strong reference (Rc-like) to the 
        //               UI component instance
        // as_weak()     
        //    This method converts the strong reference into a weak reference.
        //    A weak reference (Weak) does not contribute to the reference count, 
        //    meaning it doesn't keep the object alive.
        //    It allows you to hold a reference without preventing the object from 
        //    being dropped (deallocated) if all strong references are gone.
        let weak = main_window.as_weak();
        
        // move   Forces the closure to capture any variables from its surrounding 
        //        environment by value  
        //  ||    The parameters list of the closure. In this case, it's empty
        move || {

            let main_window = weak.unwrap();

            // Update the property is_message_visible of the main_window component
            main_window.set_is_message_visible(true);
        }
    });

    // Same structure as for on_show_message() but to handle on_close_message()
    main_window.on_close_message({

        let weak = main_window.as_weak();
        
        move || {
            let main_window = weak.unwrap();
            main_window.set_is_message_visible(false);
        }
    });

    // Start to run main_window logic
    main_window.run().unwrap();
}

